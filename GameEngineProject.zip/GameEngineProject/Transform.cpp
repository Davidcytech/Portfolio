#include "Common.h" 
#include "Transform.h"


namespace game_engine_p3d {

	Transform::Transform(float x, float y, float z)
		: position_(x, y, z), scale_(1.0f) {

		// CORRE��O DO FIXME: Inicializa a orienta��o como um quaternion identidade (sem rota��o).
		// O construtor padr�o glm::quat(1.0f, 0.0f, 0.0f, 0.0f) faz exatamente isto.
		orientation_ = glm::quat(1.0f, 0.0f, 0.0f, 0.0f);

		// Inicializa a matriz de modelo como identidade
		matrix_ = glm::mat4(1.0f);

		// Atualiza a matriz de modelo com a transforma��o inicial
		matrix_ = glm::translate(matrix_, position_);
		LOG("Transform created at position: (" << x << ", " << y << ", " << z << ")");
	}

	Transform::Transform(float x, float y, float z, float pitch, float yaw, float roll, float scale_x, float scale_y, float scale_z)
		: position_(x, y, z), scale_(scale_x, scale_y, scale_z) {

		// CORRE��O DO FIXME: Em vez de guardar os �ngulos diretamente num vec3, convertemos
		// os �ngulos de Euler iniciais (pitch, yaw, roll) para quaternions individuais e
		// multiplicamo-los para obter a orienta��o final combinada livre de Gimbal Lock.
		glm::quat q_pitch = glm::angleAxis(glm::radians(pitch), glm::vec3(1.0f, 0.0f, 0.0f));
		glm::quat q_yaw = glm::angleAxis(glm::radians(yaw), glm::vec3(0.0f, 1.0f, 0.0f));
		glm::quat q_roll = glm::angleAxis(glm::radians(roll), glm::vec3(0.0f, 0.0f, 1.0f));

		// Ordem de rota��o padr�o (Yaw * Pitch * Roll) para consist�ncia espacial
		orientation_ = q_yaw * q_pitch * q_roll;
		orientation_ = glm::normalize(orientation_); // Garante que mant�m tamanho unit�rio

		// Inicializa a matriz de modelo como identidade
		matrix_ = glm::mat4(1.0f);

		// Constru��o correta da matriz unificada com Quaternions: Matrix = T * R * S
		glm::mat4 translation_matrix = glm::translate(glm::mat4(1.0f), position_);
		glm::mat4 rotation_matrix = glm::mat4_cast(orientation_); // Converte o quaternion para mat4 direto
		glm::mat4 scale_matrix = glm::scale(glm::mat4(1.0f), scale_);

		matrix_ = translation_matrix * rotation_matrix * scale_matrix;

		LOG("Transform created at position: (" << x << ", " << y << ", " << z << ") with orientation: ("
			<< pitch << ", " << yaw << ", " << roll << ") and scale: ("
			<< scale_x << ", " << scale_y << ", " << scale_z << ")");
	}

	void Transform::Translate(float delta_x, float delta_y, float delta_z) {
		position_ += glm::vec3(delta_x, delta_y, delta_z);

		// Recalcula a matriz inteira para evitar que erros de floating-point acumulem ao transladar ap�s rodar
		glm::mat4 translation_matrix = glm::translate(glm::mat4(1.0f), position_);
		glm::mat4 rotation_matrix = glm::mat4_cast(orientation_);
		glm::mat4 scale_matrix = glm::scale(glm::mat4(1.0f), scale_);
		matrix_ = translation_matrix * rotation_matrix * scale_matrix;

		LOG("Translated by (" << delta_x << ", " << delta_y << ", " << delta_z << ")");
	}

	void Transform::Rotate(float delta_pitch, float delta_yaw, float delta_roll) {
		// CORRE��O DO FIXME: Aqui estava o perigo do Gimbal Lock!
		// Antigamente faz�amos "orientation_ += vec3(...)". Agora, criamos quaternions incrementais
		// para a rota��o deste frame e multiplicamo-los pela orienta��o atual do objeto.
		glm::quat q_dpitch = glm::angleAxis(glm::radians(delta_pitch), glm::vec3(1.0f, 0.0f, 0.0f));
		glm::quat q_dyaw = glm::angleAxis(glm::radians(delta_yaw), glm::vec3(0.0f, 1.0f, 0.0f));
		glm::quat q_droll = glm::angleAxis(glm::radians(delta_roll), glm::vec3(0.0f, 0.0f, 1.0f));

		// Multiplica��o � direita acumula a rota��o no espa�o LOCAL do objeto (comportamento desejado em jogos)
		orientation_ = orientation_ * (q_dyaw * q_dpitch * q_droll);
		orientation_ = glm::normalize(orientation_); // Previne que o objeto distor�a ou mude de tamanho com o tempo

		// Atualiza a matriz global combinando a nova rota��o
		glm::mat4 translation_matrix = glm::translate(glm::mat4(1.0f), position_);
		glm::mat4 rotation_matrix = glm::mat4_cast(orientation_);
		glm::mat4 scale_matrix = glm::scale(glm::mat4(1.0f), scale_);
		matrix_ = translation_matrix * rotation_matrix * scale_matrix;

		LOG("Rotated by (" << delta_pitch << ", " << delta_yaw << ", " << delta_roll << ")");
	}

	void Transform::Scale(float scale_x, float scale_y, float scale_z) {
		scale_ *= glm::vec3(scale_x, scale_y, scale_z);

		// Reconstr�i a matriz com os novos valores de escala
		glm::mat4 translation_matrix = glm::translate(glm::mat4(1.0f), position_);
		glm::mat4 rotation_matrix = glm::mat4_cast(orientation_);
		glm::mat4 scale_matrix = glm::scale(glm::mat4(1.0f), scale_);
		matrix_ = translation_matrix * rotation_matrix * scale_matrix;

		LOG("Scaled by (" << scale_x << ", " << scale_y << ", " << scale_z << ")");
	}
}