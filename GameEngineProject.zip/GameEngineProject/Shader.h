#pragma once

// ============================================================================
// Ficheiro:    Shader.h
// Descri��o:   Declara��o da classe Shader (Pipeline Gr�fico Program�vel)
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: GLEW, OpenGL, GLM, Windows SDK, TypeTraits, String, Vector, Map
// Observa��es: Classe respons�vel pela gest�o de Shaders OpenGL. Controla o
//              carregamento, compila��o e vincula��o (linking) dos est�gios do
//              pipeline (Vertex, Fragment, etc.) e a passagem de dados (Uniforms).
// ============================================================================

#define GLEW_STATIC // Requisito obrigat�rio antes de incluir 'glew.h' para liga��o est�tica da biblioteca
#include <GL/glew.h>
#include <glm/gtc/type_ptr.hpp> // Necess�rio para mapeamento de ponteiros de dados via glm::value_ptr()
#include <type_traits>          // Necess�rio para introspe��o de tipos em tempo de compila��o (std::is_same)
#include <string>
#include <vector>
#include <map>

namespace game_engine_p3d {

    // Descritor de est�gio de Shader. Encapsula o tipo, ficheiro de origem e ID na GPU.
    struct ShaderSource {
        unsigned int type;     // Tipo de est�gio (ex: GL_VERTEX_SHADER, GL_FRAGMENT_SHADER). Abstra�do para maior portabilidade.
        std::string filename;  // Caminho do ficheiro descritor de c�digo-fonte (.vert, .frag, etc.)
        unsigned int shader;   // Identificador interno do objeto shader gerado pela API OpenGL
    };

    class Shader {
    public:
        // --------------------------------------------------------------------
        // Construtores e Destrutores
        // --------------------------------------------------------------------
        // Construtor principal. Efetua o parsing, compila��o de cada est�gio e o linking do programa final.
        Shader(const std::vector<ShaderSource>& sources, const std::string name = {});

        // Destrutor. Garante a elimina��o e liberta��o do programa ativado na GPU.
        ~Shader();

        // --------------------------------------------------------------------
        // Getters / M�todos de Acesso (Const-Safe)
        // --------------------------------------------------------------------
        unsigned int shader_program() const { return shader_program_; } // Retorna o ID �nico do Shader Program na GPU
        std::string name() const { return name_; }                       // Retorna o nome identificador do shader

        // --------------------------------------------------------------------
        // M�todos P�blicos Operacionais e Uniforms (Templates)
        // --------------------------------------------------------------------
        void Use() const; // Vincula (bind) o programa de shader atual ao pipeline de execu��o do OpenGL

        // Fun��o gen�rica (Compile-Time Dispatch) para envio de vari�veis Uniform para a GPU.
        // Utiliza introspe��o para mapear o tipo T �s fun��es nativas glProgramUniform da API est�vel OpenGL.
        template <typename T>
        void SetUniform(const std::string& name, const T& value) const {
            // Garante o binding do programa antes do upload de dados
            glUseProgram(shader_program_);

            // Introspe��o moderna de recursos (OpenGL 4.3+ API standard)
            GLint location = glGetProgramResourceLocation(shader_program_, GL_UNIFORM, name.c_str());
            if (location == -1) {
                LOG("Error: Uniform '" << name << "' not found in shader program.");
                return;
            }

            // Avalia��o de tipos via Type Traits e coer��o expl�cita de mem�ria com reinterpret_cast
            if (std::is_same<T, float>::value) {
                glProgramUniform1f(shader_program_, location, *reinterpret_cast<const float*>(&value));
            }
            else if (std::is_same<T, int>::value) {
                glProgramUniform1i(shader_program_, location, *reinterpret_cast<const int*>(&value));
            }
            else if (std::is_same<T, glm::vec2>::value) {
                glProgramUniform2fv(shader_program_, location, 1, glm::value_ptr(*reinterpret_cast<const glm::vec2*>(&value)));
            }
            else if (std::is_same<T, glm::vec3>::value) {
                glProgramUniform3fv(shader_program_, location, 1, glm::value_ptr(*reinterpret_cast<const glm::vec3*>(&value)));
            }
            else if (std::is_same<T, glm::vec4>::value) {
                glProgramUniform4fv(shader_program_, location, 1, glm::value_ptr(*reinterpret_cast<const glm::vec4*>(&value)));
            }
            else if (std::is_same<T, glm::mat3>::value) {
                glProgramUniformMatrix3fv(shader_program_, location, 1, GL_FALSE, glm::value_ptr(*reinterpret_cast<const glm::mat3*>(&value)));
            }
            else if (std::is_same<T, glm::mat4>::value) {
                glProgramUniformMatrix4fv(shader_program_, location, 1, GL_FALSE, glm::value_ptr(*reinterpret_cast<const glm::mat4*>(&value)));
            }
            else {
                LOG("Error: Unsupported uniform type for '" << name << "'.");
                return;
            }
        }

    private:
        // --------------------------------------------------------------------
        // M�todos Privados Auxiliares (Compila��o e Pipeline)
        // --------------------------------------------------------------------
        unsigned int LoadShaders(std::vector<ShaderSource>& sources); // Centraliza a compila��o por est�gio e faz a liga��o final
        const char* ReadShader(const char* filename);                 // Utilit�rio de I/O para carregar o c�digo-fonte brutos em disco

        // --------------------------------------------------------------------
        // Atributos Privados
        // --------------------------------------------------------------------
        std::vector<ShaderSource> sources_{}; // Lista de metadados e ficheiros fonte associados a este pipeline
        unsigned int shader_program_ = 0;     // ID �nico do execut�vel final resultante do Linker do OpenGL
        std::string name_;                    // Tag descritiva opcional (�til para ferramentas de Debugging/Profiling)
    };
}