#version 440 core

uniform mat4 Model;
uniform mat4 View;
uniform mat4 ModelView;		// View * Model

uniform sampler2D TexSampler;

// Estrutura da fonte de luz ambiente global
struct AmbientLight {
	vec3 ambient;	// Componente de luz ambiente global
};

uniform AmbientLight ambientLight; // Fonte de luz ambiente global

// Estrutura de uma fonte de luz direcional
struct DirectionalLight	{
	vec3 direction;		// Dire��o da luz, espa�o do mundo
	
	vec3 ambient;		// Componente de luz ambiente
	vec3 diffuse;		// Componente de luz difusa
	vec3 specular;		// Componente de luz especular
};

uniform DirectionalLight directionalLight; // Fonte de luz direcional

// Estrutura de uma fonte de luz pontual
struct PointLight	{
	vec3 position;		// Posi��o do ponto de luz, espa�o do mundo
	
	vec3 ambient;		// Componente de luz ambiente
	vec3 diffuse;		// Componente de luz difusa
	vec3 specular;		// Componente de luz especular
	
	float constant;		// Coeficiente de atenua��o constante
	float linear;		// Coeficiente de atenua��o linear
	float quadratic;	// Coeficiente de atenua��o quadr�tica
};

uniform PointLight pointLight[2]; // Duas fontes de luz pontual

// Estrutura de uma fonte de luz c�nica
struct SpotLight {
	vec3 position;		// Posi��o do foco de luz, espa�o do mundo
	
	vec3 ambient;		// Componente de luz ambiente
	vec3 diffuse;		// Componente de luz difusa
	vec3 specular;		// Componente de luz especular
	
	float constant;		// Coeficiente de atenua��o constante
	float linear;		// Coeficiente de atenua��o linear
	float quadratic;	// Coeficiente de atenua��o quadr�tica

	float spotCutoff, spotExponent;
	vec3 spotDirection;
};

uniform SpotLight spotLight; // Fonte de luz c�nica

struct Material{
	vec3 emissive;
	vec3 ambient;		// Ka
	vec3 diffuse;		// kd
	vec3 specular;		// ke
	float shininess;
};

uniform Material material;
vec3 diffuseColor;

in vec3 vPositionEyeSpace;
in vec3 vNormalEyeSpace;
in vec2 textureCoord;

layout (location = 0) out vec4 fColor; // Cor final do fragmento

vec4 calcAmbientLight(AmbientLight light);
vec4 calcDirectionalLight(DirectionalLight light, out vec4 ambient);
vec4 calcPointLight(PointLight light, out vec4 ambient);
vec4 calcSpotLight(SpotLight light, out vec4 ambient);

void main()
{
	// Cor do Material
	// Se exsitir uma textura, ent�o a cor do material � a cor da textura.
	diffuseColor = texture(TexSampler, textureCoord).rgb;
	// Sen�o
	//diffuseColor = material.diffuse;

	// C�lculo da componente emissiva do material.
	vec4 emissive = vec4(material.emissive, 1.0);

	// Luz Ambiente Global
	vec4 ambient;

	// C�lculo do efeito da ilumina��o no fragmento.
	vec4 light[4];
	vec4 ambientTmp;
	// Contribui��o da fonte de luz ambiente
	ambient = calcAmbientLight(ambientLight);
	// Contribui��o da fonte de luz direcional
	light[0] = calcDirectionalLight(directionalLight, ambientTmp);
	ambient += ambientTmp;
	// Contribui��o de cada fonte de luz Pontual
	for(int i=0; i<2; i++) {
		light[i+1] = calcPointLight(pointLight[i], ambientTmp);
		ambient += ambientTmp;
	}
	// Contribui��o da fonte de luz c�nica
	light[3] = calcSpotLight(spotLight, ambientTmp);
	ambient += ambientTmp;

	// Afetar a componente ambiente pela cor do material
	ambient *= vec4(diffuseColor,1.0);

	// C�lculo da cor final do fragmento.
	// ----------------------------------------------------------------
	// Combinar luzes de forma mais realista
	vec4 directLighting = vec4(0.0);
	float totalWeight = 0.0;

	// Somar contribui��es com pesos baseados na dist�ncia/intensidade
	for(int i = 0; i < 4; i++) {
		if(length(light[i].rgb) > 0.001) { // Apenas se a luz contribui significativamente
			float weight = 1.0 / (1.0 + length(light[i].rgb)); // Peso inversamente proporcional � intensidade
			directLighting += light[i] * weight;
			totalWeight += weight;
		}
	}

	// Normalizar pela soma dos pesos
	if(totalWeight > 0.0) {
		directLighting /= totalWeight;
	}

	// Combinar com ambiente de forma mais suave
	vec4 finalAmbient = ambient * 0.2; // Reduzir ainda mais a contribui��o ambiente
	fColor = emissive + finalAmbient + directLighting;
	fColor = min(fColor, 1.0);
	// ----------------------------------------------------------------

	// ************************************************************************
	// Apenas para efeitos de demonstra��o, definir a cor do fragmento como 'magenta'
	// NOTA: Esta linha deve ser removida quando o c�digo estiver a funcionar corretamente.
	// ************************************************************************
	// Definindo a cor do fragmento como 'magenta'
	//fColor = vec4(1.0f, 0.0f, 1.0f, 1.0f);
}

vec4 calcAmbientLight(AmbientLight light) {
	// C�lculo da contribui��o da fonte de luz ambiente global, para a cor do objeto.
	vec4 ambient = vec4(material.ambient * light.ambient, 1.0);
	return ambient;
}

vec4 calcDirectionalLight(DirectionalLight light, out vec4 ambient) {
	// C�lculo da reflex�o da componente da luz ambiente.
	ambient = vec4(material.ambient * light.ambient, 1.0);

	// C�lculo da reflex�o da componente da luz difusa.
	vec3 lightDirectionEyeSpace = (View * vec4(light.direction, 0.0)).xyz;
	vec3 L = normalize(-lightDirectionEyeSpace); // Dire��o inversa � da dire��o luz. Isto �, um vetor que aponta da superf�cie do objeto em dire��o � fonte de luz.
	vec3 N = normalize(vNormalEyeSpace);
	float NdotL = max(dot(N, L), 0.0);
	vec4 diffuse = vec4(diffuseColor * light.diffuse, 1.0) * NdotL;
	
	// C�lculo da reflex�o da componente da luz especular.
	// Como os c�lculos est�o a ser realizados nas coordenadas do olho, ent�o a c�mara est� na posi��o (0,0,0).
	// Resulta ent�o um vetor V entre os pontos (0,0,0) e vPositionEyeSpace:
	//		V = (0,0,0) - vPositionEyeSpace = (0-vPositionEyeSpace.x, 0-vPositionEyeSpace.y, 0-vPositionEyeSpace.z)
	// Nota que multiplicar o vetor de posi��o da c�mara pela matriz View resulta no vetor (0,0,0).
	// Que pode ser simplificado como:
	//		- vPositionEyeSpace
	vec3 V = normalize(-vPositionEyeSpace);
	//vec3 H = normalize(L + V);	// Modelo Blinn-Phong
	vec3 R = reflect(-L, N);
	float RdotV = max(dot(R, V), 0.0);
	//float NdotH = max(dot(N, H), 0.0);	// Modelo Blinn-Phong
	vec4 specular = pow(RdotV, material.shininess) * vec4(light.specular * material.specular, 1.0);

	// C�lculo da contribui��o da fonte de luz direcional para a cor final do fragmento.
	return (diffuse + specular);
}

vec4 calcPointLight(PointLight light, out vec4 ambient) {
	// C�lculo da reflex�o da componente da luz ambiente.
	ambient = vec4(material.ambient * light.ambient, 1.0);

	// C�lculo da reflex�o da componente da luz difusa.
	//************************************************************************
	// Aten��o: vec3 lightPositionEyeSpace = mat3(View) * light.position; � diferente de vec3 lightPositionEyeSpace = (View * vec4(light.position, 1.0)).xyz;
	//************************************************************************
	vec3 lightPositionEyeSpace = (View * vec4(light.position, 1.0)).xyz;
	vec3 L = normalize(lightPositionEyeSpace - vPositionEyeSpace);
	vec3 N = normalize(vNormalEyeSpace);
	float NdotL = max(dot(N, L), 0.0);
	vec4 diffuse = vec4(diffuseColor * light.diffuse, 1.0) * NdotL;

	// C�lculo da reflex�o da componente da luz especular.
	// Como os c�lculos est�o a ser realizados nas coordenadas do olho, ent�o a c�mara est� na posi��o (0,0,0).
	// Resulta ent�o um vetor V entre os pontos (0,0,0) e vPositionEyeSpace:
	//		V = (0,0,0) - vPositionEyeSpace = (0-vPositionEyeSpace.x, 0-vPositionEyeSpace.y, 0-vPositionEyeSpace.z)
	// Nota que multiplicar o vetor de posi��o da c�mara pela matriz View resulta no vetor (0,0,0).
	// Que pode ser simplificado como:
	//		- vPositionEyeSpace
	vec3 V = normalize(-vPositionEyeSpace);
	//vec3 H = normalize(L + V);	// Modelo Blinn-Phong
	vec3 R = reflect(-L, N);
	float RdotV = max(dot(R, V), 0.0);
	//float NdotH = max(dot(N, H), 0.0);	// Modelo Blinn-Phong
	vec4 specular = pow(RdotV, material.shininess) * vec4(light.specular * material.specular, 1.0);
	
	// attenuation
	float dist = length(lightPositionEyeSpace - vPositionEyeSpace);	// C�lculo da dist�ncia entre o ponto de luz e o v�rtice
	float attenuation = 1.0 / (light.constant + light.linear * dist + light.quadratic * (dist * dist));

	// C�lculo da contribui��o da fonte de luz pontual para a cor final do fragmento.
	return (attenuation * (diffuse + specular));
}

vec4 calcSpotLight(SpotLight light, out vec4 ambient) 
{
	// C�lculo da reflex�o da componente da luz ambiente.
	ambient = vec4(material.ambient * light.ambient, 1.0);

	// C�lculo da reflex�o da componente da luz difusa.
	vec3 lightPositionEyeSpace = (View * vec4(light.position, 1.0)).xyz;
	vec3 L = normalize(lightPositionEyeSpace - vPositionEyeSpace);
	vec3 N = normalize(vNormalEyeSpace);
	float NdotL = max(dot(N, L), 0.0);
	vec4 diffuse = vec4(diffuseColor * light.diffuse, 1.0) * NdotL;

	// C�lculo da reflex�o da componente da luz especular.
	// Como os c�lculos est�o a ser realizados nas coordenadas do olho, ent�o a c�mara est� na posi��o (0,0,0).
	// Resulta ent�o um vetor V entre os pontos (0,0,0) e vPositionEyeSpace:
	//		V = (0,0,0) - vPositionEyeSpace = (0-vPositionEyeSpace.x, 0-vPositionEyeSpace.y, 0-vPositionEyeSpace.z)
	// Nota que multiplicar o vetor de posi��o da c�mara pela matriz View resulta no vetor (0,0,0).
	// Que pode ser simplificado como:
	//		- vPositionEyeSpace
	vec3 V = normalize(-vPositionEyeSpace);
	//vec3 H = normalize(L + V);	// Modelo Blinn-Phong
	vec3 R = reflect(-L, N);
	float RdotV = max(dot(R, V), 0.0);
	//float NdotH = max(dot(N, H), 0.0);	// Modelo Blinn-Phong
	vec4 specular = pow(RdotV, material.shininess) * vec4(light.specular * material.specular, 1.0);

	// SPOT EXPONENT
	// Effective light intensity is attenuated by the cosine of the angle between the direction of the light and the direction from the light to the vertex being lighted, raised to the power of the spot exponent.
	// Thus, higher spot exponents result in a more focused light source, regardless of the spot cutoff angle.
	// SPOT CUTOFF
	// Is a single integer or floating-point value that specifies the maximum spread angle of a light source.
	// Only values in the range 0 90 are accepted.
	// If the angle between the direction of the light and the direction from the light to the vertex being lighted is greater than the spot cutoff angle, the light is completely masked.
	// Otherwise, its intensity is controlled by the spot exponent and the attenuation factors.
	float spotIntensity;
	float spotCos = dot(L, normalize((View * vec4(-light.spotDirection, 0.0)).xyz)); // Cosseno do �ngulo definido entre o vetor L (da fonte de luz ao fragmento) e o vetor (invertido) da dire��o do foco de luz.
	if(acos(spotCos) > radians(light.spotCutoff)) {
		spotIntensity = 0.0f;
	}
	else {
		spotIntensity = pow(spotCos, light.spotExponent);
	}
	diffuse *= spotIntensity;
	specular *= spotIntensity;

	// attenuation
	float dist = length(lightPositionEyeSpace - vPositionEyeSpace);	// C�lculo da dist�ncia entre o ponto de luz e o v�rtice
	float attenuation = 1.0 / (light.constant + light.linear * dist + light.quadratic * (dist * dist));

	// C�lculo da contribui��o da fonte de luz pontual para a cor final do fragmento.
	return (attenuation * (diffuse + specular));
}