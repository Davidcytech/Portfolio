#version 440 core

uniform mat4 Model;			// Uniforms n�o utilizados podem ser removidos pelo compilador. Tamb�m se verifica o mesmo para atributos. Ligar um atributo do VS a uma vari�vel que n�o � utilizada no FS, faz com que o compilador remova a liga��o.
uniform mat4 View;
uniform mat4 ModelView;		// View * Model
uniform mat4 Projection;
uniform mat3 NormalMatrix;

in vec3 vPosition;			// Coordenadas locais do v�rtice
in vec2 vTexture;			// Coordenadas de textura
in vec3 vNormal;			// Normal do v�rtice

out vec3 vPositionEyeSpace;
out vec2 textureCoord;
out vec3 vNormalEyeSpace;

void main()
{ 
	// Posi��o do v�rtice em coordenadas do olho.
	vPositionEyeSpace = (ModelView * vec4(vPosition, 1.0)).xyz;

	// Transformar a normal do v�rtice.
	vNormalEyeSpace = normalize(NormalMatrix * vNormal);

	textureCoord = vTexture;

	// Posi��o final do v�rtice (em coordenadas de clip)
	gl_Position = Projection * ModelView * vec4(vPosition, 1.0f);
}