// Inclui o cabeçalho correspondente que já traz todas as dependências blindadas
#include "Table.h"
#include "Material.h" 

namespace game_engine_p3d {

    Table::Table(Shader* shader) :
        Object("MesaSnooker", "Default", nullptr, nullptr,
            0.0f, -2.1f, 0.0f,   // Posição X, Y, Z
            0.0f, 0.0f, 0.0f,    // Rotação
            18.0f, 1.0f, 9.0f)   // Escala
    {
        // Uso explícito do namespace std:: para evitar conflitos
        std::vector<glm::vec3> positions;
        std::vector<glm::vec3> normals;
        std::vector<glm::vec2> texcoords;

        float vertexData[] = {
            // Topo (Face Superior)
            -1.0f, 0.05f, -0.5f,    0.0f, 1.0f, 0.0f,
             1.0f, 0.05f, -0.5f,    0.0f, 1.0f, 0.0f,
             1.0f, 0.05f,  0.5f,    0.0f, 1.0f, 0.0f,
             1.0f, 0.05f,  0.5f,    0.0f, 1.0f, 0.0f,
            -1.0f, 0.05f,  0.5f,    0.0f, 1.0f, 0.0f,
            -1.0f, 0.05f, -0.5f,    0.0f, 1.0f, 0.0f,

            // Fundo (Face Inferior)
            -1.0f,-0.05f, -0.5f,    0.0f,-1.0f, 0.0f,
             1.0f,-0.05f,  0.5f,    0.0f,-1.0f, 0.0f,
             1.0f,-0.05f, -0.5f,    0.0f,-1.0f, 0.0f,
             1.0f,-0.05f,  0.5f,    0.0f,-1.0f, 0.0f,
            -1.0f,-0.05f, -0.5f,    0.0f,-1.0f, 0.0f,
            -1.0f,-0.05f,  0.5f,    0.0f,-1.0f, 0.0f,

            // Frente
            -1.0f,-0.05f,  0.5f,    0.0f, 0.0f, 1.0f,
             1.0f,-0.05f,  0.5f,    0.0f, 0.0f, 1.0f,
             1.0f, 0.05f,  0.5f,    0.0f, 0.0f, 1.0f,
             1.0f, 0.05f,  0.5f,    0.0f, 0.0f, 1.0f,
            -1.0f, 0.05f,  0.5f,    0.0f, 0.0f, 1.0f,
            -1.0f,-0.05f,  0.5f,    0.0f, 0.0f, 1.0f,

            // Trás
            -1.0f,-0.05f, -0.5f,    0.0f, 0.0f,-1.0f,
             1.0f, 0.05f, -0.5f,    0.0f, 0.0f,-1.0f,
             1.0f,-0.05f, -0.5f,    0.0f, 0.0f,-1.0f,
             1.0f, 0.05f, -0.5f,    0.0f, 0.0f,-1.0f,
            -1.0f,-0.05f, -0.5f,    0.0f, 0.0f,-1.0f,
            -1.0f, 0.05f, -0.5f,    0.0f, 0.0f,-1.0f,

            // Direita
             1.0f,-0.05f,  0.5f,    1.0f, 0.0f, 0.0f,
              1.0f,-0.05f, -0.5f,    1.0f, 0.0f, 0.0f,
              1.0f, 0.05f, -0.5f,    1.0f, 0.0f, 0.0f,
              1.0f, 0.05f, -0.5f,    1.0f, 0.0f, 0.0f,
              1.0f, 0.05f,  0.5f,    1.0f, 0.0f, 0.0f,
              1.0f,-0.05f,  0.5f,    1.0f, 0.0f, 0.0f,

              // Esquerda
              -1.0f,-0.05f,  0.5f,   -1.0f, 0.0f, 0.0f,
              -1.0f, 0.05f, -0.5f,   -1.0f, 0.0f, 0.0f,
              -1.0f,-0.05f, -0.5f,   -1.0f, 0.0f, 0.0f,
              -1.0f, 0.05f, -0.5f,   -1.0f, 0.0f, 0.0f,
              -1.0f,-0.05f,  0.5f,   -1.0f, 0.0f, 0.0f,
              -1.0f, 0.05f,  0.5f,   -1.0f, 0.0f, 0.0f
        };

        for (int i = 0; i < 36; ++i) {
            positions.push_back(glm::vec3(vertexData[i * 6], vertexData[i * 6 + 1], vertexData[i * 6 + 2]));
            normals.push_back(glm::vec3(vertexData[i * 6 + 3], vertexData[i * 6 + 4], vertexData[i * 6 + 5]));
            texcoords.push_back(glm::vec2(0.0f, 0.0f));
        }

        Material* tableMaterial = new Material();
        tableMaterial->set_ambient(glm::vec3(0.0f, 0.3f, 0.0f));
        tableMaterial->set_diffuse(glm::vec3(0.0f, 0.5f, 0.0f));
        tableMaterial->set_specular(glm::vec3(0.1f, 0.1f, 0.1f));
        tableMaterial->set_shininess(32.0f);

        table_mesh_ = new Mesh(positions, texcoords, normals, tableMaterial);
        table_renderer_ = new Renderer(shader, table_mesh_);

        this->set_renderer(table_renderer_);
    }

    Table::~Table() {
        if (table_renderer_) delete table_renderer_;
    }
}