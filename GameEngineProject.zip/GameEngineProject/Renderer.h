#pragma once


// ==============================================================
// Ficheiro:    Renderer.h
// Descri��o:   Declara��o da classe Renderer
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: Shader.h, Material.h, Mesh.h
// Observa��es:
// Esta classe representa um renderizador (em ingl�s, "renderer") que pode ser usado para desenhar (em ingl�s, "render") objetos 3D no jogo.
// Ela cont�m um material, que � respons�vel por definir o shader, a textura e as propriedades f�sicas do objeto.
// A classe 'Renderer' � respons�vel por configurar o material e desenhar a malha associada ao objeto.
// ==============================================================


#include <iostream>
#include <vector>
#include <string>

#include "Material.h"   // Inclui a classe 'Material', que define as propriedades do material
#include "Mesh.h"       // Inclui a classe 'Mesh', que define a malha do objeto 3D
#include "Light.h"      // Inclui a classe 'Light', que define uma luz no jogo


namespace game_engine_p3d {

	class Shader; // Declara��o antecipada da classe 'Shader'


    class Renderer {
    public:
		// ------------------------------------------------------------
		// Construtores e destrutores
		// ------------------------------------------------------------
        Renderer(const Shader* shader, const std::string obj_filename);
        virtual ~Renderer() = default;
		// ------------------------------------------------------------
		// Outras fun��es-membro
		// ------------------------------------------------------------
		void Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection, std::string layer, std::vector<Light*> lights);    // Fun��o que desenha o objeto usando o material e o shader associado

    private:
		Material material_; // Material associado ao objeto, que cont�m o shader, as texturas e as propriedades do material
		Mesh mesh_;         // Mesh do objeto
    };
}