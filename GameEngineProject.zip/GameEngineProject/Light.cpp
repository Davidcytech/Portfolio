﻿#include "Common.h"
#include "Light.h"
namespace game_engine_p3d {
	Light::Light(const glm::vec3& ambient) :
		type_{ LightType::kAmbient },
		ambient_{ ambient }
	{
		// Construtor para luz ambiente (Ambient Light)
		// A luz ambiente não tem direção nem posição - ilumina todos os objetos da cena uniformemente
		// É usada para simular a luz indireta do ambiente (ex: luz do céu, reflexos gerais)
		LOG("Ambient light created with color: (" << ambient.r << ", " << ambient.g << ", " << ambient.b << ")");
	}
	Light::Light(const glm::vec3& direction,
		const glm::vec3& ambient,
		const glm::vec3& diffuse,
		const glm::vec3& specular
	) :
		type_{ LightType::kDirectional },
		direction_{ glm::normalize(direction) }, // Normaliza a direção para garantir que o vetor tem comprimento 1 (necessário para cálculos de iluminação corretos)
		ambient_{ ambient },
		diffuse_{ diffuse },
		specular_{ specular }
	{
		// Construtor para luz direcional (Directional Light)
		// A luz direcional não tem posição - simula uma fonte de luz infinitamente distante (ex: o Sol)
		// Todos os raios de luz são paralelos e têm a mesma direção em toda a cena
		LOG("Directional light created with direction: (" << direction_.x << ", " << direction_.y << ", " << direction_.z << ")");
	}
	Light::Light(const glm::vec3& position,
		const glm::vec3& ambient,
		const glm::vec3& diffuse,
		const glm::vec3& specular,
		float constant,
		float linear,
		float quadratic
	) :
		type_{ LightType::kPoint },
		position_{ position },
		ambient_{ ambient },
		diffuse_{ diffuse },
		specular_{ specular },
		constant_{ constant },
		linear_{ linear },
		quadratic_{ quadratic }
	{
		// Construtor para luz pontual (Point Light)
		// A luz pontual emite luz em todas as direções a partir de um ponto específico (ex: uma lâmpada)
		// A intensidade diminui com a distância, controlada pelos fatores de atenuação:
		//   - constant_:   fator constante, garante que a luz nunca fica completamente a zero
		//   - linear_:     fator linear, a luz diminui proporcionalmente à distância
		//   - quadratic_:  fator quadrático, a luz diminui de forma mais agressiva (mais realista)
		LOG("Point light created at position: (" << position_.x << ", " << position_.y << ", " << position_.z << ")");
	}
	Light::Light(const glm::vec3& position,
		const glm::vec3& direction,
		const glm::vec3& ambient,
		const glm::vec3& diffuse,
		const glm::vec3& specular,
		float constant,
		float linear,
		float quadratic,
		float cutOff,
		float outerCutOff
	) :
		type_{ LightType::kSpotlight },
		position_{ position },
		direction_{ glm::normalize(direction) }, // Normaliza a direção para garantir cálculos de iluminação corretos
		ambient_{ ambient },
		diffuse_{ diffuse },
		specular_{ specular },
		constant_{ constant },
		linear_{ linear },
		quadratic_{ quadratic },
		cutOff_{ cutOff },
		outerCutOff_{ outerCutOff }
	{
		// Construtor para luz cónica (Spotlight)
		// A spotlight emite luz num cone a partir de uma posição e direção definidas (ex: holofote, lanterna)
		//   - cutOff_:      ângulo interior do cone - dentro deste ângulo a luz tem intensidade máxima
		//   - outerCutOff_: ângulo exterior do cone - fora deste ângulo não há luz nenhuma
		//   Entre cutOff_ e outerCutOff_ a luz vai diminuindo gradualmente (suaviza as bordas do cone)
		//   A atenuação (constant_, linear_, quadratic_) funciona da mesma forma que na Point Light
		/* LOG("Spotlight created at position: (" << position_.x << ", " << position_.y << ", " << position_.z << ") with direction: (" << direction_.x << ", " << direction_.y << ", " << direction_.z << ")"); */
	}
	std::string Light::type_string() const {
		// Retorna o tipo da luz como string para fins de debug e logging
		switch (type_) {
		case LightType::kAmbient:
			return "Ambient";
		case LightType::kDirectional:
			return "Directional";
		case LightType::kPoint:
			return "Point";
		case LightType::kSpotlight:
			return "Spotlight";
		default:
			return "Unknown";
		}
	}
	bool Light::IsInLayer(Layer layer) const {
		// Verifica se a layer fornecida está na lista de layers que esta luz afeta
		// O conceito de layers funciona como um sistema de grupos/categorias:
		//   - Cada objeto do jogo pertence a uma layer (ex: "Default", "UI", "Water")
		//   - Cada luz define quais layers ilumina através da sua lista light_layers_
		//   - Se um objeto estiver numa layer que a luz não tem na sua lista, essa luz não o ilumina
		// Isto permite controlo fino sobre quais objetos são iluminados por quais luzes
		// Exemplo no bilhar: uma luz pode iluminar apenas as bolas e não a mesa, se estiverem em layers diferentes
		for (const auto& existing_layer : light_layers_) {
			if (existing_layer == layer) {
				return true; // A layer foi encontrada - esta luz afeta objetos nesta layer
			}
		}
		return false; // A layer não foi encontrada - esta luz não afeta objetos nesta layer
	}
	void Light::AddLayerToLightLayers(Layer layer) {
		// Adiciona uma layer à lista de layers que esta luz deve iluminar
		// Após adicionar a layer, todos os objetos do jogo que pertençam a essa layer
		// passarão a ser iluminados por esta luz durante a renderização
		// Exemplo de uso:
		//   spot_light->AddLayerToLightLayers("Default"); -> a spotlight ilumina todos os objetos na layer "Default"
		//   spot_light->AddLayerToLightLayers("Bolas");   -> a spotlight passa também a iluminar objetos na layer "Bolas"
		if (layer.empty()) {
			LOG("Error: Layer name cannot be empty.");
			return; // Não adiciona uma layer sem nome - seria inválida
		}
		// Verifica se a layer já está na lista para evitar duplicados
		// Ter a mesma layer duas vezes causaria iluminação duplicada nos objetos dessa layer
		for (const auto& existing_layer : light_layers_) {
			if (existing_layer == layer) {
				LOG("Layer '" << layer << "' is already in the light layers list.");
				return; // Layer já existe na lista, não adiciona duplicado
			}
		}
		light_layers_.push_back(layer);
		LOG("Layer '" << layer << "' added to light layers.");
	}
}