#pragma once


// ==============================================================
// Ficheiro:    Behaviour.h
// Descri��o:   Declara��o da classe Behaviour
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: N�o possui depend�ncias externas.
// Observa��es:
// Esta classe serve como uma 'interface' base para comportamentos que podem ser aplicados a objetos no jogo.
// ==============================================================


namespace game_engine_p3d {

	// Declara��o antecipada (forward declaration) da classe Object.
	// Necess�ria para evitar depend�ncias circulares entre Behaviour e Object.
	// Nota que n�o � necess�rio incluir aqui o cabe�alho Object.h, pois apenas declaramos que existe uma classe Object.
	// Isso permite que Behaviour conhe�a o tipo Object sem precisar conhecer sua implementa��o completa.
	class Object;


	class Behaviour {
	public:
		// ------------------------------------------------------------
		// Construtores e destrutores
		// ------------------------------------------------------------
		// Destrutor padr�o virtual
		// Indica que o compilador deve gerar automaticamente a implementa��o de um destrutor padr�o.
		// � uma alternativa � defini��o de um destrutor com corpo de fun��o vazio, i.e., Behaviour() {}
		virtual ~Behaviour() = default;

		// ------------------------------------------------------------
		// Fun��es que definem o comportamento do objeto em diferentes fases do ciclo de vida)
		// ------------------------------------------------------------
		// Fun��es virtuais
		// Estas fun��es podem ser sobrescritas por classes derivadas para alterar o seu comportamento em tempo de execu��o.
		// Usar 'override' na classe derivada ajuda a garantir que a sobrescri��o � intencional.
		virtual void Start(Object& obj) {}
		virtual void Update(Object& obj) {}
		virtual void FixedUpdate(Object& obj) {}
		virtual void PhysicsUpdate(Object& obj) {}
		virtual void LateUpdate(Object& obj) {}
		virtual void OnCollisionEnter(Object& obj, Object& other) {}
		virtual void OnCollisionExit(Object& obj, Object& other) {}
		virtual void OnTriggerEnter(Object& obj, Object& other) {}
		virtual void OnTriggerExit(Object& obj, Object& other) {}
		virtual void OnDestroy(Object& obj) {}
	};
}