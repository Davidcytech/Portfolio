#pragma once


// =============================================================
// Ficheiro:    Common.h
// Descri��o:   Defini��es comuns e macros para o jogo
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: N�o possui depend�ncias externas
// Observa��es:
// Esta � uma cole��o de defini��es, constantes e macros que podem ser usadas em todo o projeto.
// =============================================================


// -------------------------------------------------------------
// Indica��o das bibliotecas necess�rias para o projeto
// -------------------------------------------------------------
#ifdef _WIN32
// O comando #pragma comment � usado para informar ao linker quais bibliotecas devem ser vinculadas ao projeto.
#pragma comment(lib, "glew32s.lib")		// Biblioteca 'GLEW' para extens�es OpenGL.
#pragma comment(lib, "glfw3.lib")		// Biblioteca 'GLFW' para manipula��o de janelas e entrada.
#pragma comment(lib, "opengl32.lib")	// Biblioteca 'OpenGL' padr�o do Windows SDK.
#elif __APPLE__
    // macOS - linking ser� feito via CMake ou Xcode.
    // OpenGL framework � inclu�do automaticamente.
    // GLFW e GLEW devem ser instalados via Homebrew ou vcpkg.
#elif __linux__
    // Linux - linking ser� feito via CMake ou Makefile.
#endif


// ------------------------------------------------------------
// Configura��es espec�ficas da plataforma
// ------------------------------------------------------------
#ifdef __APPLE__
    // macOS requer OpenGL Core Profile e Forward Compatibility.
    // No macOS, a vers�o m�xima suportada do OpenGL � 4.1 (GLSL 4.10).
constexpr int kOpenGLMajorVersion = 4;
constexpr int kOpenGLMinorVersion = 1;
constexpr bool kRequiresCoreProfile = true;
constexpr bool kRequiresForwardCompat = true;
#else
    // Windows e Linux podem usar vers�es mais recentes.
constexpr int kOpenGLMajorVersion = 4;
constexpr int kOpenGLMinorVersion = 6;
constexpr bool kRequiresCoreProfile = false;
constexpr bool kRequiresForwardCompat = false;
#endif


// ------------------------------------------------------------
// Inclus�o de cabe�alhos padr�o do C++
// ------------------------------------------------------------
#include <iostream>


// ------------------------------------------------------------
// Configura��o de debug (deve-se usar #define para funcionar com #if)
// ------------------------------------------------------------
#define kDebugMode 0							// Modo de depura��o (1=ativado, 0=desativado).


// ------------------------------------------------------------
// Tipos de dados comuns
// ------------------------------------------------------------
using Layer = std::string;                          // Tipo para representar layers (camadas) de objetos no jogo.


// ------------------------------------------------------------
// Constantes do projeto
// ------------------------------------------------------------
// CONFIGURA��ES DO MOTOR DE JOGO
constexpr const char* kGameVersion = "1.0.0";		// Major.Minor.Patch
constexpr int kMaxFPS = 60;							// Taxa alvo de frames por segundo.
constexpr int kMaxCameras = 4;						// N�mero m�ximo de c�maras que podem ser adicionadas ao jogo.
constexpr int kMaxLights = 8;						// N�mero m�ximo de luzes que podem ser adicionadas ao jogo.
constexpr int kMaxObjects = 1000;					// N�mero m�ximo de objetos que podem ser criados no jogo.
// CONFIGURA��ES DE RENDERIZA��O
constexpr int kWindowDefaultWidth = 1280;			// Largura padr�o da janela do jogo.
constexpr int kWindowDefaultHeight = 720;			// Altura padr�o da janela do jogo.
// CONFIGURA��ES DE RECURSOS
constexpr const char* kAssetPath = "assets/";		// Caminho base para os assets (texturas, modelos, etc.).
constexpr const char* kShaderPath = "shaders/";		// Caminho base para os shaders (ficheiros .vert e .frag).
// CONFIGURA��ES DE F�SICA
constexpr float kPhysicsGravity = 9.81f;			// Acelera��o da gravidade em m/s�.
constexpr float kPhysicsTimeStep = 1.0f / kMaxFPS;	// 1/FPS em Segundos.
constexpr int kMaxCollisionObjects = 100;			// N�mero m�ximo de objetos que podem ser usados para colis�es.
constexpr int kMaxTriggerObjects = 100;				// N�mero m�ximo de objetos que podem ser usados como gatilhos (triggers).


// ------------------------------------------------------------
// Macro para logging condicional
// ------------------------------------------------------------
#if kDebugMode
#include <iostream>
// Define a macro LOG que imprime mensagens de log com o nome da fun��o atual.
// Nota que __func__ � uma macro padr�o do C++ (C++11 e superior) que permite obter o nome da fun��o atual.
#define LOG(message) std::cout << "[" << __func__ << "] -> " << message << std::endl
#else
#define LOG(message)  // LOG desativado em release.
#endif


// ------------------------------------------------------------
// Atributos padr�o para os shaders
// ------------------------------------------------------------
// Nome de atributos padr�o (hardcoded) nos shaders
constexpr const char* kVertexPositionName = "vPosition";    // Nome do atributo de posi��o dos v�rtices.
constexpr const char* kVertexNormalName = "vNormal";		// Nome do atributo de normal dos v�rtices.
constexpr const char* kVertexTexCoordName = "vTexture";     // Nome do atributo de coordenadas de textura dos v�rtices.
// Nome dos uniforms padr�o (hardcoded) nos shaders
constexpr const char* kModelMatrixName = "Model";			// Nome do uniform da matriz Model.
constexpr const char* kViewMatrixName = "View";			    // Nome do uniform da matriz View.
constexpr const char* kModelViewMatrixName = "ModelView";	// Nome do uniform da matriz ModelView.
constexpr const char* kProjectionMatrixName = "Projection"; // Nome do uniform da matriz Projection.
// Nome do uniform da textura
constexpr const char* kTextureSamplerName = "texture1";	    // Nome do uniform do sampler de textura.
// Nome dos uniforms de propriedades do material
constexpr const char* kMaterialAmbientName = "material.ambient";	    // Nome do uniform da propriedade ambient do material.
constexpr const char* kMaterialDiffuseName = "material.diffuse";	    // Nome do uniform da propriedade diffuse do material.
constexpr const char* kMaterialSpecularName = "material.specular";	    // Nome do uniform da propriedade specular do material.
constexpr const char* kMaterialEmissiveName = "material.emissive";	    // Nome do uniform da propriedade emissive do material.
constexpr const char* kMaterialShininessName = "material.shininess";    // Nome do uniform da propriedade shininess do material.
constexpr const char* kMaterialIndexOfRefractionName = "material.indexOfRefraction"; // Nome do uniform da propriedade indexOfRefraction do material.
constexpr const char* kMaterialOpacityName = "material.opacity";          // Nome do uniform da propriedade opacity do material.
constexpr const char* kMaterialIlluminationModelName = "material.illuminationModel"; // Nome do uniform da propriedade illuminationModel do material.
// Nome dos uniforms de propriedades da luz
constexpr const char* kLightPositionName = "light.position";	// Nome do uniform da propriedade position da luz.
constexpr const char* kLightAmbientName = "light.ambient";		// Nome do uniform da propriedade ambient da luz.
constexpr const char* kLightDiffuseName = "light.diffuse";		// Nome do uniform da propriedade diffuse da luz.
constexpr const char* kLightSpecularName = "light.specular";	// Nome do uniform da propriedade specular da luz.