#pragma once


// ==============================================================
// Ficheiro:    Object.h
// Descri��o:   Declara��o da classe Object
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: Transform.h
// Observa��es:
// Esta classe representa um objeto no jogo.
// ==============================================================


#include <vector> // Para std::vector

#include "Transform.h" // Inclui a classe 'Transform'


namespace game_engine_p3d {

	// N�o � necess�rio incluir os ficheiros de cabe�alho completos, apenas fazer declara��es antecipadas (forward declarations).
	// Isto � suficiente quando se usa apenas apontadores ou refer�ncias a essas classes.
	// Esta abordagem reduz o tempo de compila��o e evita depend�ncias circulares.
	class Game; // Declara��o antecipada da classe 'Game'
	class Camera; // Declara��o antecipada da classe 'Camera'
	class Light; // Declara��o antecipada da classe 'Light'
	class Renderer; // Declara��o antecipada da classe 'Renderer'
	class Behaviour; // Declara��o antecipada da classe 'Behaviour'


	class Object {
	public:
		// ------------------------------------------------------------
		// Construtores e destrutores
		// ------------------------------------------------------------
		Object(std::string name, Layer layer, Behaviour* behaviour, Renderer* renderer, 
			float x, float y, float z, float pitch = 0.0f, float yaw = 0.0f, float roll = 0.0f,
			float scale_x = 1.0f, float scale_y = 1.0f, float scale_z = 1.0f); // Construtor com par�metros
		~Object() = default;	// Destrutor padr�o (indico ao compilador para gerar o destrutor padr�o)
		// ------------------------------------------------------------
		// Accessors e mutators
		// ------------------------------------------------------------
		int id() const { return id_; }				// Retorna o ID do objeto
		std::string name() const { return name_; }	// Retorna o nome do objeto
		Layer layer() const { return layer_; }		// Retorna a layer do objeto
		void set_game(Game* game) { game_ = game; }	// Associa a inst�ncia do jogo ao objeto
		Game* game() const { return game_; }		// Retorna a inst�ncia do jogo associada ao objeto
		Transform& model() { return model_; }		// Retorna a transforma��o associada ao objeto (matriz Model)
		// ------------------------------------------------------------
		// Fun��es de ciclo de vida do objeto
		// ------------------------------------------------------------
		void Start();
		void Update();
		void FixedUpdate();
		void PhysicsUpdate();
		void LateUpdate();
		void OnCollisionEnter(Object& other);
		void OnCollisionExit(Object& other);
		void OnTriggerEnter(Object& other);
		void OnTriggerExit(Object& other);
		void OnDestroy();
		void Draw(Camera& camera, std::vector<Light*>& lights);

	private:
		// ------------------------------------------------------------
		// Dados-membro privados
		// ------------------------------------------------------------
		static int object_count_;	// Contador de objetos
		int id_ = 0;				// ID do objeto
		std::string name_{};		// Nome do objeto (n�o pode ser vazio)
		Layer layer_ = "Default";	// Layer do objeto (padr�o: "Default")
		Game* game_ = nullptr;		// Apontador para o jogo ao qual o objeto pertence
		Transform model_;			// Transforma��o associada ao objeto (matriz Model)
		Behaviour* behaviour_ = nullptr;	// Comportamento associado ao objeto (pode ser nulo se n�o houver comportamento)
		Renderer* renderer_ = nullptr;		// Renderizador associado ao objeto (usado para desenhar o objeto). Pode ser nulo, se n�o houver renderiza��o associada.
	};
}