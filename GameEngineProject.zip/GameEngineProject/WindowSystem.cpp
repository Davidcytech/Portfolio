#include "Common.h"
#include "WindowSystem.h"


namespace game_engine_p3d {

	// Declara e inicializa o apontador est�tico para a janela GLFW
	GLFWwindow* WindowSystem::window_ = nullptr;


	WindowSystem::WindowSystem(int width, int height, const char* title) {
		LOG("Initializing WindowSystem...");

		// Exibe uma mensagem de log com a vers�o do GLFW
		LOG("GLFW version: " << glfwGetVersionString());

		// Regista a fun��o de callback para gest�o de erros do GLFW
		glfwSetErrorCallback([](int error, const char* description) {
			LOG("GLFW Error: " << error << " - " << description);
			});

		// Inicializa a biblioteca GLFW
		// Garantir que a biblioteca GLFW � inicializada antes da biblioteca GLEW
		if (!glfwInit()) {
			LOG("Failed to initialize GLFW.");
			return;
		}

		// ------------------------------------------------
		// CONFIGURA��O ESPEC�FICA PARA VERS�ES OPENGL
		// ------------------------------------------------
		LOG("Configuring OpenGL context for platform...");
		LOG("OpenGL version: " << kOpenGLMajorVersion << "." << kOpenGLMinorVersion);

		// Define a vers�o m�nima do OpenGL
		glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, kOpenGLMajorVersion);
		glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, kOpenGLMinorVersion);
#ifdef __APPLE__
		// Configura��es espec�ficas baseadas na plataforma
		if (kRequiresCoreProfile) {
			LOG("Using Core Profile (required for macOS)");
			glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
		}

		if (kRequiresForwardCompat) {
			LOG("Enabling Forward Compatibility (required for macOS)");
			glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
		}
#endif

		// Cria uma janela GLFW
		window_ = glfwCreateWindow(
			width, height, // Define a resolu��o da janela
			title, // Define o t�tulo da janela
			nullptr, // Define funcionamento em modo janela (n�o em modo fullscreen)
			nullptr // N�o partilha contexto com outra janela
		);
		if (!window_) {
			LOG("Failed to create GLFW window.");
			glfwTerminate();
			return;
		}

		// Define a janela atual como a janela de contexto
		glfwMakeContextCurrent(window_);

		// Define o apontador de utilizador da janela (apontador de uso gen�rico) para a inst�ncia atual de Input
		// Necess�rio para que a fun��o de callback de teclado possa aceder os dados da inst�ncia de Input
		glfwSetWindowUserPointer(window_, this);

		// Define o cursor do rato como vis�vel e normal
		glfwSetInputMode(window_, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
		// Permite que as teclas mantenham o estado pressionado mesmo ap�s serem soltas
		glfwSetInputMode(window_, GLFW_STICKY_KEYS, GLFW_TRUE);
		// Permite que os bot�es do rato mantenham o estado pressionado mesmo ap�s serem soltos
		glfwSetInputMode(window_, GLFW_STICKY_MOUSE_BUTTONS, GLFW_TRUE);

		// Regista a fun��o de callback para eventos de teclado
		// NOTE: Para simplificar o c�digo, n�o vamos implementar a fun��o de callback de teclado aqui.
		// Vamos recorrer apenas �s fun��es de entrada do GLFW para verificar o estado das teclas, tais como glfwGetKey().
		//glfwSetKeyCallback(window_, [](GLFWwindow* window, int key, int scancode, int action, int mods) {/*...*/});

		LOG("WindowSystem initialized.");
	}

	void WindowSystem::Finalize() {
		if (window_) {
			LOG("Finalizing WindowSystem...");
			glfwDestroyWindow(window_);
			window_ = nullptr;
		}
		glfwTerminate();
		LOG("WindowSystem finalized.");
	}

	void WindowSystem::ProcessInput() {
		LOG("Processing input...");

		// Processa eventos da janela GLFW, atualizando o estado das teclas e do rato
		glfwPollEvents();
	}

	void WindowSystem::ProcessInputWait() {
		LOG("Processing input with wait...");
		// Processa eventos da janela GLFW e espera por eventos
		// A execu��o deste m�todo bloqueia at� que haja eventos dispon�veis, como teclas pressionadas ou movimento do rato
		// Atualiza o estado das teclas e do rato
		glfwWaitEvents();
	}

	// Retorna 'true' se a tecla foi (est�) pressionada e 'false' caso contr�rio
	bool WindowSystem::GetKey(int key) {
		if (glfwGetKey(window_, key) == GLFW_PRESS) {
			LOG("***** Key " << key << " is pressed.");
			return true; // A tecla foi (ou est�) pressionada
		}
		else {
			LOG("***** Key " << key << " is not pressed.");
			return false; // A tecla n�o foi (ou n�o est�) pressionada
		}
	}

	// Retorna 'true' se o bot�o do rato foi (est�) pressionado e 'false' caso contr�rio
	bool WindowSystem::GetMouseButton(int button) {
		if (glfwGetMouseButton(window_, button) == GLFW_PRESS) {
			LOG("***** Mouse button " << button << " is pressed.");
			return true; // O bot�o do rato foi (ou est�) pressionado
		}
		else {
			LOG("***** Mouse button " << button << " is not pressed.");
			return false; // O bot�o do rato n�o foi (ou n�o est�) pressionado
		}
	}

	// Retorna a posi��o atual do rato na janela como um par de coordenadas (x, y)
	std::pair<float, float> WindowSystem::GetMousePosition() {
		double xpos, ypos;
		glfwGetCursorPos(window_, &xpos, &ypos);
		LOG("***** Mouse position: (" << xpos << ", " << ypos << ")");
		return std::make_pair<float, float>(static_cast<float>(xpos), static_cast<float>(ypos));
	}
}