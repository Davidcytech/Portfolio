#pragma once

// ============================================================================
// Ficheiro:    Mesh.h
// Descri��o:   Declara��o da classe Mesh (Geometria e Buffers 3D)
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: GLEW, GLFW, glm (OpenGL Mathematics), Vector, String
// Observa��es: Representa uma malha geom�trica 3D. Processa o parsing de ficheiros 
//              OBJ e faz a gest�o dos respetivos buffers do OpenGL (VAO e VBOs) 
//              mapeando-os para as 'locations' do pipeline gr�fico.
// ============================================================================

#include <vector>
#include <string>
#include <glm/glm.hpp>

namespace game_engine_p3d {

    // Declara��es antecipadas (Forward Declarations)
    class Shader;

    class Mesh {
    public:
        // --------------------------------------------------------------------
        // Construtores e Destrutores
        // --------------------------------------------------------------------
        // Construtor que carrega o ficheiro OBJ e inicializa os buffers no OpenGL
        Mesh(const Shader* shader, const std::string& obj_filename);

        // Liberta os buffers criados (VAO e VBOs) da mem�ria da GPU
        ~Mesh();

        // --------------------------------------------------------------------
        // Getters / M�todos de Acesso
        // --------------------------------------------------------------------
        int vertex_count() { return static_cast<int>(v_.size()); } // Retorna a quantidade de v�rtices na malha

        // --------------------------------------------------------------------
        // M�todos P�blicos Operacionais
        // --------------------------------------------------------------------
        void Use(void) const; // Vincula (bind) o VAO para preparar a renderiza��o da malha

    private:
        // --------------------------------------------------------------------
        // M�todos Privados Auxiliares (Parsing e I/O)
        // --------------------------------------------------------------------
        void ObjLoader(const std::string& obj_filename);          // Coordenador principal do carregamento do ficheiro .obj
        bool isObjFile(const std::string file);                    // Valida se a extens�o do ficheiro corresponde a um .obj
        const char* loadDataFromObjFile(const std::string file);  // L� o conte�do bruto do ficheiro para mem�ria

        // Faz a tokeniza��o e extra��o de linhas com base em delimitadores (ex: "v", "vt", "vn", "f")
        std::vector<std::string> extractObjAttribute(const char* data, std::string AttributeDelimiter);

        // Calcula os limites espaciais (Bounding Box) extraindo os extremos de um vetor de vetores 3D
        void FindMaxMinFromVec(std::vector<glm::vec3> vec, glm::vec3& max, glm::vec3& min);

        // --------------------------------------------------------------------
        // Atributos Privados
        // --------------------------------------------------------------------
        // Handles/Identificadores de objetos OpenGL (GPU)
        GLuint vao_ = 0;            // Vertex Array Object (Armazena o estado dos atributos)
        GLuint vbo_vertices_ = 0;   // Vertex Buffer Object para posi��es espaciais (v)
        GLuint vbo_normals_ = 0;    // Vertex Buffer Object para vetores normais (vn)
        GLuint vbo_texcoords_ = 0;  // Vertex Buffer Object para coordenadas UV (vt)

        size_t vertex_count_ = 0;   // Cache do n�mero total de v�rtices indexados

        // Contentores de dados geom�tricos em mem�ria RAM (CPU)
        std::vector<glm::vec3> v_{};   // Posi��es dos v�rtices (X, Y, Z)
        std::vector<glm::vec2> vt_{};  // Coordenadas de mapeamento de textura / UV (U, V)
        std::vector<glm::vec3> vn_{};  // Vetores normais para c�lculo de ilumina��o

        // Caixa delimitadora (AABB - Axis-Aligned Bounding Box) para dete��o de colis�es e culling
        float min_x_ = 0.0f, max_x_ = 0.0f; // Extens�o geom�trica no eixo X
        float min_y_ = 0.0f, max_y_ = 0.0f; // Extens�o geom�trica no eixo Y
        float min_z_ = 0.0f, max_z_ = 0.0f; // Extens�o geom�trica no eixo Z
    };
}