#pragma once

// ============================================================================
// Ficheiro:    Material.h
// Descri��o:   Declara��o da classe Material (Propriedades de Superf�cie)
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: Shader.h, Texture.h, glm (OpenGL Mathematics), String, Vector
// Observa��es: Representa as propriedades �ticas e texturas de uma superf�cie 3D,
//              mapeando diretamente as especifica��es do formato padr�o MTL (Wavefront).
// ============================================================================

#include <string>
#include <vector>
#include <glm/glm.hpp>

#include "Texture.h"

namespace game_engine_p3d {

    // Declara��es antecipadas (Forward Declarations)
    class Shader;

    class Material {
    public:
        // --------------------------------------------------------------------
        // Construtores e Destrutores
        // --------------------------------------------------------------------
        // Construtor que deduz e carrega as propriedades a partir de um ficheiro OBJ/MTL
        Material(const Shader* shader, const std::string obj_filename);

        // Construtor expl�cito parametrizado com os valores padr�o do modelo Phong/MTL
        Material(
            glm::vec3 ka = glm::vec3{ 0.2f, 0.2f, 0.2f },
            glm::vec3 kd = glm::vec3{ 0.8f, 0.8f, 0.8f },
            glm::vec3 ks = glm::vec3{ 1.0f, 1.0f, 1.0f },
            glm::vec3 ke = glm::vec3{ 0.0f, 0.0f, 0.0f },
            float Ns = 32.0f,
            float Ni = 1.0f,
            float d = 1.0f,
            int illum = 2,
            Shader* shader = nullptr,
            std::vector<Texture> textures_ = {}
        );

        ~Material() = default;

        // --------------------------------------------------------------------
        // Getters e Setters (M�todos de Acesso)
        // --------------------------------------------------------------------
        Shader* shader() const { return shader_; }

        // --------------------------------------------------------------------
        // M�todos P�blicos Operacionais
        // --------------------------------------------------------------------
        void Use() const; // Ativa o pipeline do shader e vincula (bind) as texturas associadas

    private:
        // --------------------------------------------------------------------
        // M�todos Privados Auxiliares (Parsing e I/O)
        // --------------------------------------------------------------------
        // Procura a diretiva 'mtllib' no ficheiro OBJ e armazena o caminho em 'mtl_filename_'
        bool findMaterialFile(const std::string& obj_filename);

        // Efetua o parsing do ficheiro MTL para preencher os coeficientes f�sicos do material
        void LoadMaterialFromFile(void);

        // --------------------------------------------------------------------
        // Atributos Privados
        // --------------------------------------------------------------------
        std::string mtl_filename_{};       // Caminho do ficheiro descritor .mtl
        Shader* shader_ = nullptr;         // Ponteiro para o shader program respons�vel pela renderiza��o

        // Contentor de mapas de textura organizados por ordem de amostragem (Sampler Slots):
        // Slot 0: Albedo/Diffuse (map_Kd), Slot 1: Normal Map (map_bump), Slot 2: Specular (map_Ks), etc.
        std::vector<Texture> texture_{};

        // Coeficientes �ticos da Especifica��o Wavefront MTL / Ilumina��o de Phong
        glm::vec3 ka_{};   // Coeficiente de reflex�o ambiente (Ambient reflectivity / Ka)
        glm::vec3 kd_{};   // Coeficiente de reflex�o difusa (Diffuse reflectivity / Kd) -> Cor base sob luz direta
        glm::vec3 ks_{};   // Coeficiente de reflex�o especular (Specular reflectivity / Ks) -> Intensidade do brilho
        glm::vec3 ke_{};   // Intensidade emissiva (Emissive color / Ke) -> Luz pr�pria independente do cen�rio

        float Ns_{};       // Expoente especular (Specular Exponent / Shininess). Valores altos = brilho mais focado
        float Ni_{};       // �ndice de refra��o (Index of Refraction). Ex: 1.0 (Ar), 1.33 (�gua), 1.5 (Vidro)
        float d_{};        // Fator de dissolu��o/opacidade (Dissolve). 1.0 = Totalmente Opaco, 0.0 = Invis�vel
        int illum_{};      // Modelo matem�tico de ilumina��o (0: Amb, 1: Amb+Diff, 2: Amb+Diff+Spec)
    };
}