#define GLEW_STATIC // Defini��o necess�ria, antes de incluir 'GL\glew.h', sempre que se usa GLEW como uma biblioteca est�tica
#include <GL/glew.h>

#include "Common.h" // Para a macro LOG
#include "Texture.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h" // Biblioteca para carregamento de imagens


namespace game_engine_p3d {

	Texture::Texture(const std::string& path)
		: path_{ path } {
        
        if(path.empty()) {
            LOG("Error: Texture path is empty. Cannot create Texture object without a path.");
            exit(EXIT_FAILURE); // Encerra o programa com erro
		}

        // Adiciona o caminho base dos assets ao nome do ficheiro
        std::string image_filename_full = kAssetPath + path_;

		LOG("Creating Texture object with path: '" + image_filename_full << "'");

        glGenTextures(1, &texture_name_);

        glActiveTexture(GL_TEXTURE0 + texture_unit_);

        glBindTexture(GL_TEXTURE_2D, texture_name_);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

        int width, height, nChannels;
        stbi_set_flip_vertically_on_load(true);
        unsigned char* imageData = stbi_load(image_filename_full.c_str(), &width, &height, &nChannels, 0);
        if (imageData) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, nChannels == 4 ? GL_RGBA : GL_RGB, GL_UNSIGNED_BYTE, imageData);

            glGenerateMipmap(GL_TEXTURE_2D);

            stbi_image_free(imageData);
        }
        else {
            LOG("Error loading texture!");
        }
	}

    Texture::~Texture() {
        // Destrutor de texturas
        // S� destr�i na GPU se o ID for v�lido e a textura tiver sido carregada
        if (loaded_ && texture_name_ > 0) {
            glDeleteTextures(1, &texture_name_);

            // Colocamos as vari�veis a zero para seguran�a contra c�pias
            texture_name_ = 0;
            loaded_ = false;

            LOG("Texture destroyed safely from GPU.");
        }
        else {
            LOG("Texture destructor called for a copy or empty object. Ignored GPU delete.");
        }
    }

	void Texture::Use() const {
		// Indica a unidade de textura a usar
        glActiveTexture(GL_TEXTURE0 + texture_unit_);
		// Liga a textura a um ponto de liga��o do tipo textura 2D da unidade de textura ativa
        glBindTexture(GL_TEXTURE_2D, texture_name_);
        //Antes o professor tinha posto aqui uma fun��o que mantinha o id do shader fixo, est� corrigido agora
	}
}