#pragma once

// 1. PRIMEIRO: Forçar a inclusão das bibliotecas base do C++ (Resolve os erros de STD)
#include <vector>
#include <string>

// 2. SEGUNDO: Forçar a inclusão do GLM e OpenGL nativos do teu projeto
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// 3. TERCEIRO: Incluir as classes da Game Engine do professor
#include "Object.h"
#include "Mesh.h"
#include "Renderer.h"
#include "Shader.h"

namespace game_engine_p3d {

    class Table : public Object {
    public:
        Table(Shader* shader);
        virtual ~Table();

    private:
        Mesh* table_mesh_ = nullptr;
        Renderer* table_renderer_ = nullptr;
    }; // Garantido o ponto e vírgula aqui
}