﻿#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <array>
#include <string>
#include <glm\glm.hpp>
#define GLEW_STATIC
#include <GL\glew.h>

#include "Common.h" // Para definições comuns e macros
#include "Shader.h"
#include "Mesh.h"


namespace game_engine_p3d {

	template<class T> T op_StringToVec(std::string str);
	template<class T> T op_StringToArrayOfVec(std::string str);

	// ============================================================================
	// Construtor — carrega o ficheiro OBJ, cria os VBOs e configura o VAO
	// ============================================================================
	Mesh::Mesh(const Shader* shader, const std::string& obj_filename) {
		// Valida se o shader foi fornecido - sem shader não é possível renderizar a malha
		if (!shader) {
			LOG("Error: Shader is null. Cannot create Mesh without a shader.");
			exit(EXIT_FAILURE);
		}
		// Valida se o caminho para o ficheiro OBJ foi fornecido
		if (obj_filename.empty()) {
			LOG("Error: OBJ filename is empty. Cannot create Mesh without an OBJ path.");
			exit(EXIT_FAILURE);
		}

		LOG("Creating Mesh with OBJ file: " + obj_filename);

		// Concatena o caminho base dos assets com o nome do ficheiro OBJ
		// kAssetPath é definido em Common.h (ex: "assets/")
		std::string obj_filename_full = kAssetPath + obj_filename;

		// Garante que os números decimais são lidos com ponto (.) como separador
		// e não com vírgula (,), que é o separador em algumas locales (ex: português, alemão)
		// Sem isto, valores como "1.5" poderiam ser lidos incorretamente
		auto old = std::locale();
		std::locale::global(std::locale("C"));

		// Carrega os dados da malha (vértices, normais, UVs) do ficheiro OBJ para a RAM (CPU)
		ObjLoader(obj_filename_full);

		// Restaura a locale original do sistema após a leitura do ficheiro
		std::locale::global(old);

		// --------------------------------------------------------------------
		// Criação dos Vertex Buffer Objects (VBOs)
		// Buffers na GPU que armazenam os dados dos vértices de forma persistente
		// Sem eles, os dados teriam de ser enviados da CPU para a GPU em cada frame
		// --------------------------------------------------------------------
		{
			// VBO para posições dos vértices (coordenadas X, Y, Z de cada ponto da malha)
			if (!v_.empty()) {
				LOG("Vertices provided for the mesh.");
				glGenBuffers(1, &vbo_vertices_);                                                             // Gera um identificador único para o VBO
				glBindBuffer(GL_ARRAY_BUFFER, vbo_vertices_);                                                // Ativa o VBO no contexto OpenGL
				glBufferData(GL_ARRAY_BUFFER, v_.size() * sizeof(glm::vec3), v_.data(), GL_STATIC_DRAW);    // Copia os vértices da RAM para a GPU (GL_STATIC_DRAW indica que os dados não vão mudar)
			}
			else {
				LOG("Warning: No vertices provided for the mesh. Mesh will not be rendered.");
			}
			// VBO para normais (vetores perpendiculares à superfície, usados para cálculos de iluminação)
			// Sem normais, a iluminação não funciona - as bolas de bilhar não teriam sombreado correto
			if (!vn_.empty()) {
				LOG("Normals provided for the mesh.");
				glGenBuffers(1, &vbo_normals_);
				glBindBuffer(GL_ARRAY_BUFFER, vbo_normals_);
				glBufferData(GL_ARRAY_BUFFER, vn_.size() * sizeof(glm::vec3), vn_.data(), GL_STATIC_DRAW);
			}
			else {
				LOG("Warning: No normals provided for the mesh. Normals will not be used.");
			}
			// VBO para coordenadas de textura UV (mapeiam a textura 2D sobre a malha 3D)
			// São usadas para aplicar texturas (ex: o número e a cor de cada bola de bilhar)
			if (!vt_.empty()) {
				LOG("Texture coordinates provided for the mesh.");
				glGenBuffers(1, &vbo_texcoords_);
				glBindBuffer(GL_ARRAY_BUFFER, vbo_texcoords_);
				glBufferData(GL_ARRAY_BUFFER, vt_.size() * sizeof(glm::vec2), vt_.data(), GL_STATIC_DRAW);
			}
			else {
				LOG("Warning: No texture coordinates provided for the mesh. Texture coordinates will not be used.");
			}
		}

		// Obtém o ID do programa shader para associar os VBOs aos atributos corretos do shader
		GLuint programa = shader->shader_program();

		// --------------------------------------------------------------------
		// Criação e configuração do Vertex Array Object (VAO)
		// O VAO memoriza a configuração de todos os VBOs e atributos do shader
		// Em vez de configurar os VBOs manualmente a cada frame, basta ativar o VAO
		// --------------------------------------------------------------------
		{
			glGenVertexArrays(1, &vao_); // Gera um identificador único para o VAO
			glBindVertexArray(vao_);     // Ativa o VAO - todas as configurações seguintes ficam gravadas nele

			// Atributo: Vértices
			// Liga o VBO de vértices ao atributo 'vPosition' do shader
			// NOTE: Os nomes dos atributos estão hardcoded (ver ficheiro "Common.h") e devem existir no shader
			if (!v_.empty()) {
				glBindBuffer(GL_ARRAY_BUFFER, vbo_vertices_);
				GLint coordsId = glGetProgramResourceLocation(programa, GL_PROGRAM_INPUT, kVertexPositionName); // Obtém a localização do atributo no programa shader (para versões >= 4.3)
				if (coordsId == -1) {
					// Se o atributo não existir no shader, a malha não pode ser renderizada - sem vértices não há geometria
					LOG("Error: Attribute 'vPosition' not found in shader program. Mesh cannot be rendered.");
					exit(EXIT_FAILURE);
				}
				else {
					glVertexAttribPointer(coordsId, 3, GL_FLOAT, GL_FALSE, 0, nullptr); // Define o formato dos dados: 3 floats por vértice (X, Y, Z), sem normalização nem espaçamento
					glEnableVertexAttribArray(coordsId);                                 // Ativa o atributo no VAO para que o shader receba os dados deste VBO
				}
			}
			// Atributo: Normais
			// O shader usa este atributo para calcular como a luz incide em cada face da malha
			if (!vn_.empty()) {
				glBindBuffer(GL_ARRAY_BUFFER, vbo_normals_);
				GLint normalId = glGetProgramResourceLocation(programa, GL_PROGRAM_INPUT, kVertexNormalName);
				if (normalId == -1) {
					LOG("Warning: Attribute 'vNormal' not found in shader program. Normals will not be used.");
				}
				else {
					glVertexAttribPointer(normalId, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
					glEnableVertexAttribArray(normalId);
				}
			}
			// Atributo: Coordenadas de textura
			// O shader usa este atributo para saber que parte da textura aplicar a cada vértice
			if (!vt_.empty()) {
				glBindBuffer(GL_ARRAY_BUFFER, vbo_texcoords_);
				GLint textureId = glGetProgramResourceLocation(programa, GL_PROGRAM_INPUT, kVertexTexCoordName);
				if (textureId == -1) {
					LOG("Warning: Attribute 'vTexture' not found in shader program. Texture coordinates will not be used.");
				}
				else {
					glVertexAttribPointer(textureId, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
					glEnableVertexAttribArray(textureId);
				}
			}
			glBindVertexArray(0); // Desvincula o VAO para evitar modificações acidentais
		}

		LOG("Mesh created.");
	}

	// ============================================================================
	// Destrutor — liberta os recursos alocados na GPU
	// ============================================================================
	Mesh::~Mesh() {
		LOG("Destroying Mesh...");
		LOG("Destroying VAO with ID: " + std::to_string(vao_));

		// Liberta os recursos da GPU - obrigatório em OpenGL, não há garbage collector
		// Sem esta limpeza, os buffers ficavam ocupados na memória da GPU até o programa terminar
		if (vao_) glDeleteVertexArrays(1, &vao_);
		if (vbo_vertices_) glDeleteBuffers(1, &vbo_vertices_);
		if (vbo_normals_) glDeleteBuffers(1, &vbo_normals_);
		if (vbo_texcoords_) glDeleteBuffers(1, &vbo_texcoords_);

		LOG("Mesh destroyed.");
	}

	// ============================================================================
	// Use — ativa o VAO desta malha para renderização
	// ============================================================================
	void Mesh::Use(void) const {
		// Após esta chamada, o OpenGL sabe quais VBOs e atributos usar para desenhar a malha
		glBindVertexArray(vao_);
	}

	// ============================================================================
	// ObjLoader — lê e processa o ficheiro OBJ, expandindo os índices de face
	// ============================================================================
	void Mesh::ObjLoader(const std::string& obj_filename) {
		// If it is not an OBJ file, it returns error.
		if (!isObjFile(obj_filename)) {
			LOG("'" + obj_filename + "'" + " is not an '.obj' file!");
			return;
		}

		// If the OBJ file can not be opened, it returns an error.
		const char* data = loadDataFromObjFile(obj_filename);
		if (data == nullptr) {
			LOG("Error on opening file '" + obj_filename + "'!");
			return;
		}

		// O formato OBJ organiza os dados por prefixo:
		//   "v "  -> posição do vértice (X Y Z)
		//   "vt " -> coordenada de textura UV (U V)
		//   "vn " -> normal do vértice (X Y Z)
		//   "f "  -> face (índices que referenciam os v, vt e vn acima)
		// Extrai cada tipo de atributo para um vetor de strings separado
		std::vector<std::string> attributeVectorV = extractObjAttribute(data, "\nv ");   // vertex position
		std::vector<std::string> attributeVectorVt = extractObjAttribute(data, "\nvt ");  // texture coordinates
		std::vector<std::string> attributeVectorVn = extractObjAttribute(data, "\nvn ");  // vertex normal
		std::vector<std::string> attributeVectorF = extractObjAttribute(data, "\nf ");   // face index

		// Aloca vetores temporários para armazenar os dados convertidos de string para tipos numéricos
		std::vector<glm::vec4>* vTmp = new std::vector<glm::vec4>(attributeVectorV.size(), glm::vec4(1.0)); // Default value 1.0
		std::vector<glm::vec3>* vtTmp = new std::vector<glm::vec3>(attributeVectorVt.size(), glm::vec4(0.0)); // Default value 0.0
		std::vector<glm::vec3>* vnTmp = new std::vector<glm::vec3>(attributeVectorVn.size());
		std::vector<std::array<glm::ivec3, 3>>* fTmp = new std::vector<std::array<glm::ivec3, 3>>(attributeVectorF.size());

		// Converte cada string para o tipo numérico correspondente usando std::transform
		// op_StringToVec converte "1.0 2.0 3.0" → glm::vec3(1.0, 2.0, 3.0)
		std::transform(attributeVectorV.begin(), attributeVectorV.end(), vTmp->begin(), op_StringToVec<glm::vec4>);
		std::transform(attributeVectorVt.begin(), attributeVectorVt.end(), vtTmp->begin(), op_StringToVec<glm::vec3>);
		std::transform(attributeVectorVn.begin(), attributeVectorVn.end(), vnTmp->begin(), op_StringToVec<glm::vec3>);
		std::transform(attributeVectorF.begin(), attributeVectorF.end(), fTmp->begin(), op_StringToArrayOfVec<std::array<glm::ivec3 /*3 vertex per face*/, 3 /*each vertex has: v, vt, vn*/>>);

		// Face elements
		// f v1[/vt1][/vn1] v2[/vt2][/vn2] v3[/vt3][/vn3]
		// Examples:
		// f v1 v2 v3
		// f v1/vt1 v2/vt2 v3/vt3
		// f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3
		// f v1//vn1 v2//vn2 v3//vn3
		// O OBJ usa índices para reutilizar vértices - este loop "expande" esses índices
		// em vez de guardar índices, guarda os valores diretamente em v_, vt_, vn_
		// Isto é necessário porque o OpenGL (sem index buffers) precisa dos dados já expandidos
		for (std::vector<std::array<glm::ivec3, 3>>::iterator it = fTmp->begin(); it != fTmp->end(); it++) {
			std::array<glm::ivec3, 3> arrayOfVec = *it;

			// Vertices of a triangle
			glm::ivec3 vertex[3];
			for (int i = 0; i < 3; i++) { vertex[i] = arrayOfVec[i]; }

			// For each face we have v, vt and vn
			int indexOfVertexPositionForVertex[3];
			int indexOfTextureCoordinateForVertex[3];
			int indexOfVertexNormalForVertex[3];
			for (int i = 0; i < 3; i++) {
				// The index in 'face' start at the value '1', so we need to subtract one.
				// Os índices no OBJ começam em 1, subtrai-se 1 para converter para base 0 (C++)
				indexOfVertexPositionForVertex[i] = vertex[i][0/*position*/] - 1;
				indexOfTextureCoordinateForVertex[i] = vertex[i][1/*texture*/] - 1;
				indexOfVertexNormalForVertex[i] = vertex[i][2/*normal*/] - 1;

				// Load values to the attribute vectors
				v_.push_back(vTmp->at(indexOfVertexPositionForVertex[i]));         // position of vertex #0
				vt_.push_back(vtTmp->at(indexOfTextureCoordinateForVertex[i]));    // texture coordinate of vertex #0
				vn_.push_back(vnTmp->at(indexOfVertexNormalForVertex[i]));         // normal of vertex #0
			}
		}

		// Calcula os limites da malha em cada eixo (X, Y, Z)
		// Útil para cálculos de colisão (ex: detetar se uma bola saiu dos limites da mesa)
		glm::vec3 maxV, minV;
		FindMaxMinFromVec(v_, maxV, minV);
		min_x_ = minV.x; max_x_ = maxV.x;
		LOG("Mesh X axis extent: min_x = " << std::to_string(min_x_) << ", max_x = " << std::to_string(max_x_));
		min_y_ = minV.y; max_y_ = maxV.y;
		LOG("Mesh Y axis extent: min_y = " << std::to_string(min_y_) << ", max_y = " << std::to_string(max_y_));
		min_z_ = minV.z; max_z_ = maxV.z;
		LOG("Mesh Z axis extent: min_z = " << std::to_string(min_z_) << ", max_z = " << std::to_string(max_z_));

		LOG("Total number of vertex = " << std::to_string(v_.size()));

		// Liberta a memória temporária usada durante o carregamento
		delete vTmp;
		delete vtTmp;
		delete vnTmp;
		delete[] data;

		return;
	}

	// ============================================================================
	// isObjFile — verifica se o ficheiro tem extensão .obj
	// ============================================================================
	bool Mesh::isObjFile(const std::string file) {
		// Verifica se os últimos 4 caracteres do nome do ficheiro são ".obj"
		if (file.substr(file.size() - 4, 4) != ".obj") return false;
		return true;
	}

	// ============================================================================
	// loadDataFromObjFile — lê o conteúdo do ficheiro OBJ para memória
	// ============================================================================
	const char* Mesh::loadDataFromObjFile(const std::string file) {
		// Abre o ficheiro em modo binário e posiciona o cursor no fim para obter o tamanho total
		std::ifstream ficheiro(file, std::ifstream::ate | std::ifstream::binary);
		if (ficheiro.is_open()) {
			// tellg() devolve a posição atual do cursor, que após "ate" é o tamanho do ficheiro em bytes
			std::streampos tamanhoDoFicheiroEmBytes = ficheiro.tellg();
			// Volta ao início do ficheiro para começar a leitura
			ficheiro.seekg(0, std::ios::beg);

			// Aloca memória para todo o conteúdo do ficheiro mais o terminador '\0'
			char* data = new char[int(tamanhoDoFicheiroEmBytes) + 1];
			// Lê todo o ficheiro de uma vez para o array
			ficheiro.read(data, tamanhoDoFicheiroEmBytes);
			// Adiciona o terminador de string para garantir que é uma C-string válida
			data[tamanhoDoFicheiroEmBytes] = 0;

			ficheiro.close();
			return const_cast<const char*>(data);
		}
		else {
			return nullptr;
		}
	}

	// ============================================================================
	// extractObjAttribute — extrai todas as ocorrências de um atributo OBJ por delimitador
	// ============================================================================
	std::vector<std::string> Mesh::extractObjAttribute(const char* data, std::string AttributeDelimiter) {
		std::vector<std::string> retAttributeVector;
		std::string s(data);
		std::string delimiter = AttributeDelimiter;

		// Remove os caracteres '\r' (carriage return do Windows) para garantir compatibilidade
		// Sem isto, ficheiros OBJ criados no Windows poderiam ser lidos incorretamente no Linux/Mac
		s.erase(std::remove(s.begin(), s.end(), '\r'), s.end());

		// Percorre o texto à procura do delimitador (ex: "\nv ", "\nvt ")
		// e extrai o conteúdo entre cada par de delimitadores consecutivos
		size_t lastOffset = s.find(delimiter, 0); // 1st delimiter
		if (lastOffset == std::string::npos) return retAttributeVector; // If no delimiter was found
		while (true)
		{
			size_t offset = s.find(delimiter, lastOffset + 1); // next delimiter (add one to skip the delimiter)
			retAttributeVector.push_back(s.substr(lastOffset + delimiter.size(), offset - lastOffset - delimiter.size()));

			// If no delimiter was found
			if (offset == std::string::npos) break;

			lastOffset = offset;
		}

		if (kDebugMode) {
			// Limpa o delimitador para o log (remove '\r', '\n' e ' ' para ficar legível)
			delimiter.erase(std::remove(delimiter.begin(), delimiter.end(), '\r'), delimiter.end());
			delimiter.erase(std::remove(delimiter.begin(), delimiter.end(), '\n'), delimiter.end());
			delimiter.erase(std::remove(delimiter.begin(), delimiter.end(), ' '), delimiter.end());
			LOG("Number of '" + delimiter + "' elements " + " = " + std::to_string(retAttributeVector.size()));
		}

		return retAttributeVector;
	}

	// ============================================================================
	// FindMaxMinFromVec — calcula os valores máximo e mínimo de um vetor de vértices
	// ============================================================================
	void Mesh::FindMaxMinFromVec(std::vector<glm::vec3> vec, glm::vec3& max, glm::vec3& min) {
		if (vec.empty()) return;
		// Inicializa max e min com o primeiro vértice como referência
		max = vec[0];
		min = vec[0];
		// Percorre todos os vértices e atualiza max e min em cada eixo
		for (std::vector<glm::vec3>::iterator it = vec.begin(); it != vec.end(); it++) {
			glm::vec3 v = *it;
			if (v.x > max.x) max.x = v.x;
			if (v.y > max.y) max.y = v.y;
			if (v.z > max.z) max.z = v.z;
			if (v.x < min.x) min.x = v.x;
			if (v.y < min.y) min.y = v.y;
			if (v.z < min.z) min.z = v.z;
		}
	}

	// ============================================================================
	// op_StringToVec — converte uma string de valores separados por espaços num vetor glm
	// Exemplo: "1.0 2.5 3.0" → glm::vec3(1.0, 2.5, 3.0)
	// ============================================================================
	template<class T>
	T op_StringToVec(std::string str) {
		T vec(0);
		std::istringstream iss(str);
		int vecElement = 0;
		while (iss && vecElement < vec.length()) {
			iss >> vec[vecElement++];
		}
		return vec;
	}

	// ============================================================================
	// op_StringToArrayOfVec — converte uma string de face OBJ num array de vetores de índices
	// Exemplo: "1/1/1 2/2/2 3/3/3" → array com 3 ivec3: {(1,1,1), (2,2,2), (3,3,3)}
	// As barras '/' são substituídas por espaços para facilitar a leitura com istringstream
	// ============================================================================
	template<class T>
	T op_StringToArrayOfVec(std::string str) {
		T arrayOfVec{};
		replace(str.begin(), str.end(), '/', ' ');
		std::istringstream iss(str);
		for (int arrayIndex = 0; arrayIndex < arrayOfVec.size(); arrayIndex++) {
			for (int vecElement = 0; vecElement < arrayOfVec[0].length(); vecElement++) {
				iss >> arrayOfVec[arrayIndex][vecElement];
			}
		}
		return arrayOfVec;
	}
}