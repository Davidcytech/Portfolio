#define GLEW_STATIC // Defini��o necess�ria, antes de incluir 'GL\glew.h', sempre que se usa GLEW como uma biblioteca est�tica
#include <GL/glew.h>

#include "Common.h" // Inclui defini��es comuns e macros para o motor de jogo
#include "Object.h"
#include "Renderer.h"
#include "Camera.h"
#include "Behaviour.h"


namespace game_engine_p3d {

	// Define o contador de objetos est�tico, atribuindo um valor inicial de 0.
	int Object::object_count_ = 0;


	// --------------------------------------------------------------------------
	// Defini��o de fun��es da classe Object
	// --------------------------------------------------------------------------
	Object::Object(std::string name, Layer layer, Behaviour* behaviour, Renderer* renderer, 
		float x, float y, float z, 
		float pitch, float yaw, float roll, 
		float scale_x, float scale_y, float scale_z) {

		// Verifica se o nome do objeto � vazio
		if (name.empty()) {
			LOG("Error: Object name cannot be empty.");
			exit(EXIT_FAILURE); // Encerra o programa com erro
		}
		// Atribui o nome ao objeto
		name_ = name;

		// Atribui a layer ao objeto
		// Se a layer fornecida for vazia, mant�m a layer padr�o ("Default")
		if (!layer.empty()) {
			layer_ = layer;
		}

		// Atribui o comportamento (se fornecido) ao objeto. Admite valor nulo.
		behaviour_ = behaviour;

		// Atribui o renderizador (se fornecido) ao objeto. Admite valor nulo.
		renderer_ = renderer;

		// Inicializa a matriz de transforma��o do objeto com a posi��o, orienta��o e escala fornecidas
		model_ = Transform(x, y, z, pitch, yaw, roll, scale_x, scale_y, scale_z);

		// Incrementa o contador de objetos
		object_count_++;

		// Atribui um ID �nico ao objeto
		id_ = object_count_;

		LOG("Object created with ID: " << id_ << " at position: (" << x << ", " << y << ", " << z << ")");
	}

	// --------------------------------------------------------------------
		// Ciclo de Vida: Inicializa��o
		// --------------------------------------------------------------------

		// Chamado uma �nica vez quando o objeto � ativado na cena.
		// Ideal para inicializar vari�veis, carregar componentes ou configurar o estado inicial.
	void Object::Start() {
		if (behaviour_) {
			behaviour_->Start(*this);
		}
	}

	// --------------------------------------------------------------------
	// Ciclo de Vida: Loops de Updates
	// --------------------------------------------------------------------

	// Chamado uma vez por frame. � o loop principal de l�gica do jogo.
	// Utilizado para ler inputs do jogador, atualizar temporizadores e mover objetos n�o-f�sicos.
	void Object::Update() {
		if (behaviour_) {
			behaviour_->Update(*this);
		}
	}

	// Chamado a intervalos de tempo est�ticos e fixos (independente do framerate do jogo).
	// Crucial para garantir que simula��es matem�ticas ou l�gicas determin�sticas correm ao mesmo ritmo em qualquer PC.
	void Object::FixedUpdate() {
		if (behaviour_) {
			behaviour_->FixedUpdate(*this);
		}
	}

	// Chamado imediatamente antes ou durante o passo de simula��o do motor de f�sica.
	// Reservado exclusivamente para aplicar for�as f�sicas, torques e impulsos em corpos r�gidos (Rigidbodies).
	void Object::PhysicsUpdate() {
		if (behaviour_) {
			behaviour_->PhysicsUpdate(*this);
		}
	}

	// Chamado no final do frame, ap�s todos os m�todos Update normais terem sido executados.
	// Muito utilizado para fazer com que a c�mara siga um personagem, garantindo que o alvo j� se moveu naquele frame.
	void Object::LateUpdate() {
		if (behaviour_) {
			behaviour_->LateUpdate(*this);
		}
	}

	// --------------------------------------------------------------------
	// Eventos de Sistema de Colis�es (F�sica Rigidbody)
	// --------------------------------------------------------------------

	// Disparado no exato frame em que o colisor deste objeto toca noutro colisor f�sico (s�lido).
	// Utilizado para detetar impactos f�sicos, como uma bala a bater numa parede ou o jogador a tocar no ch�o.
	void Object::OnCollisionEnter(Object& other) {
		if (behaviour_) {
			behaviour_->OnCollisionEnter(*this, other);
		}
	}

	// Disparado no frame em que este objeto deixa de estar em contacto f�sico com o outro colisor.
	// �til para detetar, por exemplo, o momento em que o jogador salta e perde o contacto com uma plataforma.
	void Object::OnCollisionExit(Object& other) {
		if (behaviour_) {
			behaviour_->OnCollisionExit(*this, other);
		}
	}

	// --------------------------------------------------------------------
	// Eventos de Sistema de Triggers
	// --------------------------------------------------------------------

	// Disparado quando este objeto entra numa �rea de trigger (um colisor configurado como sensor/atravess�vel).
	// Ideal para detetar que o jogador passou por uma porta, entrou numa zona de perigo ou apanhou um item colecion�vel.
	void Object::OnTriggerEnter(Object& other) {
		if (behaviour_) {
			behaviour_->OnTriggerEnter(*this, other);
		}
	}

	// Disparado quando este objeto sai de dentro da �rea do gatilho volum�trico.
	// Utilizado para apagar luzes autom�ticas ao sair de uma sala ou fechar portas autom�ticas atr�s do jogador.
	void Object::OnTriggerExit(Object& other) {
		if (behaviour_) {
			behaviour_->OnTriggerExit(*this, other);
		}
	}

	// --------------------------------------------------------------------
	// Ciclo de Vida: Destrui��o e Limpeza
	// --------------------------------------------------------------------

	// Chamado quando o objeto � explicitamente removido da cena do jogo.
	// Limpa a liga��o com o comportamento associado para evitar fugas de mem�ria (memory leaks).
	void Object::OnDestroy() {
		if (behaviour_) {
			behaviour_ = nullptr; // Limpa o comportamento ap�s destruir
		}
	}

	void Object::Draw(Camera& camera, std::vector<Light*>& lights) {
		// Se estiver associado um renderizador
		if (renderer_) {
			// Matriz Model do objeto
			glm::mat4 model_matrix = model_.matrix_;

			// Matriz View e Projection da c�mara fornecida
			glm::mat4 view_matrix = camera.view().matrix_;
			glm::mat4 projection_matrix = camera.projection().matrix_;

			// Chama o m�todo Draw do renderizador para desenhar o objeto
			renderer_->Draw(model_matrix, view_matrix, projection_matrix, layer_, lights);
		}
	}
}	