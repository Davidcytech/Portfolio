﻿#pragma once
// ==============================================================
// Oscilator.h
// ==============================================================
#include "Behaviour.h"
#include "Object.h"
#include "Game.h"
#include "WindowSystem.h"
#include <cmath>
#include <string>

using namespace game_engine_p3d;
// ============================================================================
// Classe:       Oscilator
// Descrição:    Script de comportamento (Behaviour) responsável por controlar 
//               a física inicial, o gatilho de disparo por teclado e o estado 
//               de movimento/rotação da bola no jogo de bilhar.
// Herança:      Herda da classe base 'Behaviour' para se integrar no ciclo 
//               de vida do motor (métodos Start e Update).
// ============================================================================
class Oscilator : public Behaviour {
private:
    float tempo_ = 0.0f;            // Acumulador de tempo (útil para animações ou funções sinusoidais)
    float velocidade_ = 1.0f;       // Multiplicador global da velocidade de translação
    bool pause = false;            // Flag para alternar o estado de pausa do script
    bool movimentoIniciado = false;// Estado de controlo: true quando a bola é disparada
    //Velocidade de todos os eixos (como podemos ver apenas inicia no eixo de X)
    float velX_ = 0.1f;
    float velY_ = 0.0f;
    float velZ_ = 0.0f;

    //Varíaveis relacionadas com a rotação da bola
    float rotacaoZ = 0.0f; // Para simular o efeito de rolamento real na mesa (e não deslizar no gelo), a rotação deve ocorrer em torno do eixo perpendicular à direção do movimento linear.
    float velocidadeRotacao_ = 6.0f;

    //===================================================================//
    // Executado automaticamente uma única vez quando o script é iniciado.
    // Garante o "reset" e a inicialização segura das variáveis de controlo 
public:
    void Start(Object& object) override {
        tempo_ = 0.0f;
        movimentoIniciado = false;
        rotacaoZ = 0.0f;
    }
    //==============================================//
    //Esta é a função que trata de atualizar os componentes relacionados com o movimento da bola contendo na mesma as seguintes etapas:
    void Update(Object& object) override {
        //Definimos já o raio da bola a partir do modelo dividindo o tamanho no eixo de X por 2
        float raioBola = object.model().scale_.x / 2.0f;
        // 1. Ativação por teclado
        if (WindowSystem::GetKey(GLFW_KEY_SPACE) == true && !movimentoIniciado) { 
            movimentoIniciado = true; //Ativa o movimento a partir da tecla "espaço"
            LOG("[Oscilator] Espaço premido! Movimento iniciado.");
        }

        // 2. Movimento
        if (movimentoIniciado) {
    //Anula temporariamente a rotação visual no eixo Z.
    // Isto é feito para que a translação seguinte mova a bola na direção correta do Mundo 3D,
    // impedindo que o movimento linear fique distorcido ou "às curvas" devido à rotação acumulada.
            object.model().Rotate(0.0f, 0.0f, -rotacaoZ);
            object.model().Translate(velX_ * velocidade_, velY_ * velocidade_, velZ_ * velocidade_); //É determinado o movimento multiplicando pelo vetor velocidade de cada coordenada
            rotacaoZ -= velocidadeRotacao_ * velocidade_; //Multiplica a velocidade da rotação pela velocidade para manter as rotações proporcionais ao movimento
            object.model().Rotate(0.0f, 0.0f, rotacaoZ); //Aqui sim mudaríamos a rotação da bola
        }

        // 3. Limite da mesa
        //Nesta etapa pegamos no comprimento da mesa e paramos a bola quando a sua posição atingir o valor da varíavel metadeDamesaX. 
        if (movimentoIniciado) {
            float metadeDaMesaX = 17.5f; //Usamos apenas metade da mesa pois a bola começa no centro da mesa
            float limiteParagem = metadeDaMesaX - raioBola;

            if (object.model().position_.x >= limiteParagem) {
                LOG("[Oscilator] Atingiu o limite calculado da mesa: " << object.model().position_.x);
                velX_ = 0.0f;
                velY_ = 0.0f;
                velZ_ = 0.0f;
                movimentoIniciado = false;
                object.model().position_.x = limiteParagem;
            }
        }

        // ==================== COLISÃO ==================== //
       //Esta função pega no raio da bola e vai verificando sempre se a distância entre esta e outra bola equivale a 2* o raio
        if (movimentoIniciado) {
            Game* game = object.game();
            if (game != nullptr) {

                // Faz um loop para ler as bolas todas e verificar se estão a colidir
                for (int i = 1; i <= 15; i++) {
                    std::string nomeDaBola = "Ball" + std::to_string(i);
                    Object* outraBola = game->FindObjectByName(nomeDaBola);

                    // Verificamos se as coordenadas condizem com a de outra bola
                    if (outraBola != nullptr && outraBola != &object) {

                        float diffX = object.model().position_.x - outraBola->model().position_.x;
                        float diffY = object.model().position_.y - outraBola->model().position_.y;
                        float diffZ = object.model().position_.z - outraBola->model().position_.z;

                        float distancia = std::sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);

                        // Deteta a colisão e zera todas as posições da bola em movimento
                        if (distancia <= raioBola*2.0f) {
                            LOG("=== COLIDIU COM A " << nomeDaBola << " ===");
                            velX_ = 0.0f;
                            velY_ = 0.0f;
                            velZ_ = 0.0f;
                            movimentoIniciado = false; //tira também a flag para parar os processos de update
                            break; // Se já bateu numa bola, não precisa de testar as outras neste frame
                        }
                    }
                }
            }
        }
    }
};