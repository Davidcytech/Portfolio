#include <fstream>
#include <sstream>
#include <algorithm>

#include "Common.h"
#include "Material.h"
#include "Shader.h"
#include "Texture.h"


namespace game_engine_p3d {

    // ============================================================================
    // Construtor � deduz e carrega as propriedades a partir de um ficheiro OBJ/MTL
    // ============================================================================
    Material::Material(const Shader* shader, const std::string obj_filename) {
        // Se o shader n�o for fornecido, encerra o programa com uma mensagem de erro
        if (!shader) {
            LOG("Error: Shader is null. Cannot create Material object without a shader.");
            exit(EXIT_FAILURE);
        }
        // Se n�o for fornecido um caminho para o objeto, encerra o programa com uma mensagem de erro
        if (obj_filename.empty()) {
            LOG("Error: Object filename is empty. Cannot create Material object without an object path.");
            exit(EXIT_FAILURE);
        }

        LOG("Creating Material with shader and OBJ file: " + obj_filename);

        shader_ = (Shader*)shader; // Inicializa o shader com o fornecido

        // Adiciona o caminho base dos assets ao nome do ficheiro
        std::string obj_filename_full = kAssetPath + obj_filename;

        // A partir do ficheiro OBJ, obt�m o nome do ficheiro MTL (fica guardado em 'mtl_filename_')
        if (findMaterialFile(obj_filename_full) == false) {
            LOG("No MTL file found in OBJ file: '" << obj_filename_full << "'");
            return;
        }

        // Carrega as propriedades do material (e instancia as Texturas) a partir do ficheiro MTL
        LoadMaterialFromFile();

        // Se a flag de debug estiver ativa, imprime as propriedades do material
        if (kDebugMode) {
            LOG("Material properties:");
            LOG("  Ambient Color: " << ka_.r << " " << ka_.g << " " << ka_.b);
            LOG("  Diffuse Color: " << kd_.r << " " << kd_.g << " " << kd_.b);
            LOG("  Specular Color: " << ks_.r << " " << ks_.g << " " << ks_.b);
            LOG("  Emissive Color: " << ke_.r << " " << ke_.g << " " << ke_.b);
            LOG("  Shininess: " << Ns_);
            LOG("  Index of Refraction: " << Ni_);
            LOG("  Opacity: " << d_);
            LOG("  Illumination Model: " << illum_);
            if (texture_.size() >= 1) LOG("  Texture: '" << texture_.at(0).path() << "'");
            else LOG("  Texture: None");
            if (texture_.size() >= 2) LOG("  Normal Map: '" << texture_.at(1).path() << "'");
            else LOG("  Normal Map: None");
        }

        LOG("Material created with shader and object path: " + obj_filename);
    }

    // ============================================================================
    // Construtor � expl�cito parametrizado com os valores padr�o do modelo Phong/MTL
    // ============================================================================
    Material::Material(glm::vec3 ka, glm::vec3 kd, glm::vec3 ks, glm::vec3 ke, float Ns, float Ni, float d, int illum,
        Shader* shader, std::vector<Texture> textures) {
        // Inicializa as propriedades do material com os valores fornecidos ou padr�es
        ka_ = ka;            // Cor ambiente
        kd_ = kd;            // Cor difusa
        ks_ = ks;            // Cor especular
        ke_ = ke;            // Cor emissiva
        Ns_ = Ns;            // Exponente de reflex�o especular
        Ni_ = Ni;            // �ndice de refra��o
        d_ = d;              // Opacidade
        illum_ = illum;      // Modelo de ilumina��o
        shader_ = shader;    // Shader associado ao material
        texture_ = textures; // Texturas do material, se fornecidas
    }

    // ============================================================================
    // Use � ativa o shader, vincula as texturas e envia os uniforms para a GPU
    // ============================================================================
    void Material::Use() const {
        // Ativa o shader do material
        if (shader_) {
            shader_->Use();
        }

        // Ativa e vincula cada textura na sua unidade de textura correspondente
        // GL_TEXTURE0 + i seleciona o slot correto (Slot 0: Diffuse, Slot 1: Normal, etc.)
        for (size_t i = 0; i < texture_.size(); i++) {
            glActiveTexture(GL_TEXTURE0 + static_cast<GLenum>(i)); // Ativa a unidade de textura correspondente
            texture_.at(i).Use();                                   // Vincula e usa a textura atual
        }

        // Envia os coeficientes �ticos do material como uniforms para o shader
        if (shader_) {
            shader_->SetUniform<glm::vec3>(kMaterialAmbientName, ka_);
            shader_->SetUniform<glm::vec3>(kMaterialDiffuseName, kd_);
            shader_->SetUniform<glm::vec3>(kMaterialSpecularName, ks_);
            shader_->SetUniform<glm::vec3>(kMaterialEmissiveName, ke_);
            shader_->SetUniform<float>(kMaterialShininessName, Ns_);
            shader_->SetUniform<float>(kMaterialIndexOfRefractionName, Ni_);
            shader_->SetUniform<float>(kMaterialOpacityName, d_);
            shader_->SetUniform<int>(kMaterialIlluminationModelName, illum_);
        }

        LOG("Material used.");
        LOG("  Ambient Color: " << ka_.r << " " << ka_.g << " " << ka_.b);
        LOG("  Diffuse Color: " << kd_.r << " " << kd_.g << " " << kd_.b);
        LOG("  Specular Color: " << ks_.r << " " << ks_.g << " " << ks_.b);
        LOG("  Emissive Color: " << ke_.r << " " << ke_.g << " " << ke_.b);
        LOG("  Shininess: " << Ns_);
        LOG("  Index of Refraction: " << Ni_);
        LOG("  Opacity: " << d_);
        LOG("  Illumination Model: " << illum_);
    }

    // ============================================================================
    // findMaterialFile � procura a diretiva 'mtllib' no OBJ e guarda o caminho MTL
    // ============================================================================
    bool Material::findMaterialFile(const std::string& obj_filename) {
        std::string delimiter = "mtllib ";
        std::string mtlFile;

        LOG("Looking for MTL file in OBJ file: '" << obj_filename << "'");

        // Abre o ficheiro OBJ para ler o nome do ficheiro MTL
        std::ifstream obj_file(obj_filename);
        if (!obj_file.is_open()) {
            LOG("Failed to open OBJ file: '" << obj_filename << "'");
            return false;
        }

        // L� o ficheiro linha a linha � procura da diretiva "mtllib"
        std::string obj_line;
        while (std::getline(obj_file, obj_line)) {
            size_t pos = obj_line.find(delimiter, 0);
            if (pos != std::string::npos) {
                // Extrai o nome do ficheiro MTL ap�s o delimitador
                mtlFile = obj_line.substr(pos + delimiter.length(), obj_line.find('\n', pos) - (pos + delimiter.length()));

                // Remove os caracteres '\r' que podem estar presentes antes do '\n' (compatibilidade Windows)
                mtlFile.erase(std::remove(mtlFile.begin(), mtlFile.end(), '\r'), mtlFile.end());

                obj_file.close();
                mtl_filename_ = mtlFile; // Guarda o nome do ficheiro MTL encontrado
                return true;
            }
        }

        return false; // Retorna falso se n�o encontrar a diretiva 'mtllib'
    }

    // ============================================================================
    // LoadMaterialFromFile � faz o parse do MTL e preenche os coeficientes do material
    // ============================================================================
    void Material::LoadMaterialFromFile(void) {

        // Adiciona o caminho base dos assets ao nome do ficheiro
        std::string mtl_filename_full = kAssetPath + mtl_filename_;

        LOG("Loading material properties from file: '" << mtl_filename_full << "'");

        std::ifstream file(mtl_filename_full);
        if (!file.is_open()) {
            LOG("Failed to open MTL file: '" << mtl_filename_full << "'");
            return;
        }

        // Faz o parse do ficheiro linha a linha, identificando cada propriedade pelo seu prefixo MTL
        std::string line;
        while (std::getline(file, line)) {
            std::istringstream iss(line);
            std::string prefix;
            iss >> prefix;

            if (prefix == "Ka") {            // Coeficiente ambiente
                iss >> ka_.r >> ka_.g >> ka_.b;
            }
            else if (prefix == "Kd") {       // Coeficiente difuso
                iss >> kd_.r >> kd_.g >> kd_.b;
            }
            else if (prefix == "Ks") {       // Coeficiente especular
                iss >> ks_.r >> ks_.g >> ks_.b;
            }
            else if (prefix == "Ke") {       // Coeficiente emissivo
                iss >> ke_.r >> ke_.g >> ke_.b;
            }
            else if (prefix == "Ns") {       // Exponente especular (shininess)
                iss >> Ns_;
            }
            else if (prefix == "Ni") {       // �ndice de refra��o
                iss >> Ni_;
            }
            else if (prefix == "d") {        // Opacidade (dissolve)
                iss >> d_;
            }
            else if (prefix == "illum") {    // Modelo de ilumina��o
                iss >> illum_;
            }
            else if (prefix == "map_Kd") {   // Mapa de textura difusa (Slot 0)
                std::string texture_path;
                iss >> texture_path;
                texture_.push_back(Texture(texture_path));
            }
            else if (prefix == "map_Ks") {   // Mapa de textura especular (Slot 1)
                std::string specular_map_path;
                iss >> specular_map_path;
                texture_.push_back(Texture(specular_map_path));
            }
            else if (prefix == "map_Ke") {   // Mapa de textura emissiva (Slot 2)
                std::string emissive_map_path;
                iss >> emissive_map_path;
                texture_.push_back(Texture(emissive_map_path));
            }
            else if (prefix == "map_Bump") { // Mapa de normais (Slot 3)
                std::string normal_map_path;
                iss >> normal_map_path;
                texture_.push_back(Texture(normal_map_path));
            }
        }

        file.close();
        LOG("Material properties loaded.");
    }
}