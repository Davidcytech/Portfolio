#pragma once


// =============================================================
// Ficheiro:    WindowSystem.h
// Descri��o:   Declara��o da classe 'WindowSystem'
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: GLFW, GLEW
// Compila��o:	g++ WindowSystem.h -o WindowSystem.o -lglew32s -lglfw3 -lopengl32
// Observa��es:
// A classe inicializa uma janela atrav�s da biblioteca GLFW.
// Define a resolu��o da janela e o t�tulo, e permite capturar eventos de teclado e rato.
// =============================================================


#include <utility> // std::pair
//--------------------------------------------------------------
#define GLEW_STATIC // Defini��o necess�ria, antes de incluir 'GL\glew.h', sempre que se usa GLEW como uma biblioteca est�tica.
#include <GL/glew.h> // Certifique-se de que a biblioteca GLEW est� instalada e configurada corretamente no seu sistema.
//--------------------------------------------------------------
#define GLFW_USE_DWM_SWAP_INTERVAL // Defini��o necess�ria para usar o intervalo de troca do DWM (Desktop Window Manager) no GLFW.
#include <GLFW/glfw3.h> // Certifique-se de que a biblioteca GLFW est� instalada e configurada corretamente no seu sistema.


namespace game_engine_p3d {

	class WindowSystem {
	public:
		// ------------------------------------------------------------
		// Construtores e destrutores
		// ------------------------------------------------------------
		WindowSystem() = default;								// Construtor padr�o (necess�rio para a instancia��o da classe Game).
		WindowSystem(int width, int height, const char* title);	// Construtor, onde se inicializa o sistema de entrada.
		// ------------------------------------------------------------
		// Accessors e mutators
		// ------------------------------------------------------------
		GLFWwindow* window() const { return window_; }		// Retorna o apontador para a janela GLFW, que pode ser usado para outras opera��es.
		// ------------------------------------------------------------
		// Outras fun��es-membro
		// ------------------------------------------------------------
		void ProcessInput();			// Processa a entrada do utilizador (utilizar no loop do jogo).
		void ProcessInputWait();		// Processa a entrada do utilizador e espera por eventos (utilizar quando o estado do jogo for de pausa).
		void Finalize();				// Finaliza o sistema de entrada, destruindo a janela e liberando recursos.
		// ------------------------------------------------------------
		// Wrapper para criar uma interface unificada para as fun��es de entrada do GLFW
		// ------------------------------------------------------------
		static bool GetKey(int key);						// Leitura do estado de uma tecla.
		static bool GetMouseButton(int button);				// Leitura do estado de um bot�o do rato.
		static std::pair<float, float> GetMousePosition();	// Leitura da posi��o do rato na janela.

	private:
		static GLFWwindow* window_;
	};
}