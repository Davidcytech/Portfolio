﻿#pragma once

// ============================================================================
// Ficheiro:    Game.h
// Descrição:   Declaração da classe Game (Core do Motor de Jogo)
// Autor:       Duarte Duque
// Data:        21/07/2025
// Versão:      1.0.0
// Dependências: Common.h, Camera.h, Light.h, Object.h, WindowSystem.h
// Observações: Classe principal que gere o ciclo de vida do jogo (Game Loop),
//              estados, objetos de cena, iluminação, câmaras e renderização.
// ============================================================================

#include <iostream>
#include <vector>
#include <string>

#include "Common.h"       // Definições comuns (ex: kWindowDefaultWidth, kWindowDefaultHeight)
#include "Camera.h"       // Gestão de câmaras e pontos de vista
#include "Light.h"        // Gestão de fontes de iluminação
#include "Object.h"       // Gestão de entidades/objetos 3D na cena
#include "WindowSystem.h" // Gestão da janela da aplicação e input (teclado/rato)

namespace game_engine_p3d {

    class Game {
    public:
        // --------------------------------------------------------------------
        // Tipos de Dados Suportados
        // --------------------------------------------------------------------
        // Máquina de estados para controlo do fluxo principal do motor.
        // Encapsulado dentro da classe para evitar poluição do namespace global.
        enum class GameState {
            kGameStateInitialization, // Configuração inicial e carregamento de recursos
            kGameStateGameLoop,       // Ciclo principal (Atualização e Renderização)
            kGameStateShutdown        // Libertação de memória e encerramento
        };

        // --------------------------------------------------------------------
        // Construtores e Destrutores
        // --------------------------------------------------------------------
        // Inicializa a janela com dimensões e título padrão ou definidos pelo utilizador.
        Game(unsigned int width = kWindowDefaultWidth, unsigned int height = kWindowDefaultHeight, const char* title = "Game Window");

        // Garante o encerramento seguro do WindowSystem e libertação de recursos.
        ~Game();

        // --------------------------------------------------------------------
        // Getters / Métodos de Acesso (Const-Safe)
        // --------------------------------------------------------------------
        GameState state() const { return state_; }       // Obtém o estado atual do jogo
        unsigned int width() const { return width_; }    // Obtém a largura atual da janela
        unsigned int height() const { return height_; }  // Obtém a altura atual da janela

        // --------------------------------------------------------------------
        // Métodos de Gestão de Jogo e Cena
        // --------------------------------------------------------------------
        void AddCamera(Camera* camera);  // Regista uma nova câmara na cena
        void AddLight(Light* light);     // Regista uma nova fonte de luz na cena
        void AddObject(Object* object);  // Adiciona um objeto dinâmico ou estático ao mundo

        // Procura um objeto na cena através do seu identificador (string). Retorna nullptr se não encontrar.
        Object* FindObjectByName(const std::string& name);

        void Run();  // Inicia o Game Loop principal e processa o input continuamente
        void Exit(); // Solicita a interrupção do Game Loop para encerrar o jogo

    private:
        // --------------------------------------------------------------------
        // Métodos Privados Auxiliares
        // --------------------------------------------------------------------
        void FrameRateControl(double fps); // Limita e estabiliza a taxa de quadros por segundo (FPS)

        // --------------------------------------------------------------------
        // Atributos Privados
        // --------------------------------------------------------------------
        GameState state_ = GameState::kGameStateInitialization;
        unsigned long int frameCount_ = 0; // Total de frames processados desde o arranque
        double delta_time_ = 0.0;          // Tempo decorrido entre o frame anterior e o atual (em segundos) é usado para medir a velocidade por segundo multiplicando a velocidade por frames para rodar igual em todos os pcs

        // Relação de COMPOSIÇÃO: O ciclo de vida da janela está estritamente ligado ao objeto Game.
        WindowSystem window_system_;

        unsigned int width_;
        unsigned int height_;
        char const* title_;

        // Relação de AGREGAÇÃO: O jogo gere os ponteiros, mas o ciclo de vida dos objetos 
        // pode ser independente (ex: instanciados fora ou partilhados).
        std::vector<Camera*> cameras_{};   // Lista de câmaras. O índice 0 é assumido como a câmara principal.
        std::vector<Light*> lights_{};     // Lista de luzes ativas no mundo 3D
        std::vector<Object*> objects_{};   // Lista de entidades renderizáveis em cena

        // Histórico do estado das teclas (0-9) no frame anterior.
        // Utilizado para detetar eventos do tipo "OnKeyPress" (evita gatilhos repetidos enquanto segura a tecla).
        bool keys_pressed_[10] = { false };
    };
}