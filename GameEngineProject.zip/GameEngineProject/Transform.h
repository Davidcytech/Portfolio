#pragma once

// ============================================================================
// Ficheiro:    Transform.h
// Descri��o:   Declara��o da classe Transform (Cinem�tica e Matrizes 3D)
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.1.0 (Atualizado: Migra��o para Quaternions)
// Depend�ncias: GLM (OpenGL Mathematics)
// Observa��es: Encapsula a posi��o, rota��o espacial e escala de uma entidade 3D.
//              A rota��o utiliza Quaternions para evitar problemas de Gimbal Lock.
// ============================================================================

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/quaternion.hpp>

namespace game_engine_p3d {

    class Transform {
    public:
        // --------------------------------------------------------------------
        // Construtores e Destrutores
        // --------------------------------------------------------------------
        Transform() = default;

        // Construtor utilit�rio para defini��o apenas de posi��o espacial
        Transform(float x, float y, float z);

        // Construtor completo: Converte os �ngulos de Euler iniciais internamente para Quaternion
        Transform(float x, float y, float z, float pitch, float yaw, float roll,
            float scale_x = 1.0f, float scale_y = 1.0f, float scale_z = 1.0f);

        ~Transform() = default;

        // --------------------------------------------------------------------
        // M�todos P�blicos de Transforma��o
        // --------------------------------------------------------------------
        void Translate(float delta_x, float delta_y, float delta_z);

        // Aplica uma rota��o incremental acumulando-a de forma segura via Quaternions
        void Rotate(float delta_pitch, float delta_yaw, float delta_roll);

        void Scale(float scale_x, float scale_y, float scale_z);

        // Reconstr�i a matriz de transforma��o global (Model Matrix) a partir de Posi��o, Rota��o e Escala
        void UpdateMatrix();

        // --------------------------------------------------------------------
        // Dados-Membro P�blicos
        // --------------------------------------------------------------------
        glm::vec3 position_ = glm::vec3(0.0f);  // Vetor de transla��o espacial (X, Y, Z)

        /*
         * Corrigido O FIXME: Substitui��o de Euler (vec3) para Quaternion (quat).
         * Ao guardar a rota��o como um quaternion em vez de tr�s �ngulos independentes (pitch/yaw/roll),
         * eliminamos por completo o problema do Gimbal Lock (bloqueio de cardan que alinha dois eixos
         * e faz o objeto perder um grau de liberdade). Inicializado como quaternion identidade.
         */
        glm::quat orientation_ = glm::quat(1.0f, 0.0f, 0.0f, 0.0f);

        glm::vec3 scale_ = glm::vec3(1.0f);     // Fatores de escala nos eixos locais (X, Y, Z)
        glm::mat4 matrix_ = glm::mat4(1.0f);    // Matriz de transforma��o afim global (Model Matrix)
    };
}