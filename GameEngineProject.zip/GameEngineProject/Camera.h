#pragma once


// =============================================================
// Ficheiro:    Camera.h
// Descri��o:   Classe para representar uma c�mara 3D
// Autor:       Duarte Duque
// Data:        21/07/2025
// Vers�o:      1.0.0
// Depend�ncias: Common.h, Transform.h
// Compila��o:	g++ Camera.h -o Camera.o -lglew32s -lglfw3 -lopengl32
// Observa��es:
// Esta classe encapsula a posi��o, orienta��o e escala de uma c�mara 3D.
// =============================================================


#include <vector>
#include <tuple> // std::tuple<>

#include "Common.h" // Inclui defini��es comuns e macros para o motor de jogo (neste caso, � necess�rio para utiliza��o de 'WINDOW_DEFAULT_WIDTH' e 'WINDOW_DEFAULT_HEIGHT')
#include "Transform.h" // Inclui a classe 'Transform' para manipula��o de matrizes


namespace game_engine_p3d {

	class Camera {
	public:
		// ------------------------------------------------------------
		// Tipos de dados
		// ------------------------------------------------------------
		// Enumera��o para definir o tipo de c�mara (perspectiva ou ortogr�fica)
		// Foi definida dentro da classe 'Camera' para encapsular o tipo de c�mara e evitar polui��o do namespace global.
		enum class CameraType {
			kNone = -1,		// Nenhum tipo de c�mara definido
			kPerspective,	// C�mara perspetiva
			kOrthographic	// C�mara ortogr�fica
		};

		// ------------------------------------------------------------
		// Construtores e destrutores
		// ------------------------------------------------------------
		Camera() = default;		// Construtor padr�o (indico ao compilador para gerar o construtor padr�o)
		~Camera() = default;	// Destrutor padr�o (indico ao compilador para gerar o destrutor padr�o)
		// ------------------------------------------------------------
		// Wrappers para fun��es OpenGL e GLM
		// ------------------------------------------------------------
		void LookAt(const glm::vec3& eye, const glm::vec3& center, const glm::vec3& up); // Wrapper para glm::lookAt
		void Prespective(float fov, float aspect, float near_plane, float far_plane); // Wrapper para glm::perspective
		void Orthographic(float left, float right, float bottom, float top, float near_plane, float far_plane); // Wrapper para glm::ortho
		void Viewport(int width, int height, int x, int y); // Wrapper para a fun��o viewport do OpenGL
		void Viewport() const; // Wrapper para a fun��o viewport do OpenGL com os valores atribu�dos aos dados-membro da classe Camera
		// ------------------------------------------------------------
		// Accessors e mutators
		// ------------------------------------------------------------
		Transform& view() { return view_; } // Retorna a matriz de visualiza��o da c�mara
		void set_view(const Transform& view) { view_ = view; } // Define a matriz de visualiza��o da c�mara
		Transform& projection() { return projection_; } // Retorna a matriz de proje��o da c�mara
		void set_projection(const Transform& projection) { projection_ = projection; } // Define a matriz de proje��o da c�mara
		glm::vec4 background_color() const { return background_color_; } // Retorna a cor de fundo da c�mara
		void set_background_color(const glm::vec4& color) { background_color_ = color; } // Define a cor de fundo da c�mara
		std::vector<Layer>& culling_mask() { return culling_mask_; } // Retorna a m�scara de culling da c�mara
		// ------------------------------------------------------------
		// Outras fun��es-membro
		// ------------------------------------------------------------
		void AddLayerToCullingMask(Layer layer); // Adiciona uma layer � m�scara de culling da c�mara
		// Fun��o que retorna o viewport da c�mara, ou seja, as dimens�es e posi��o da viewport associada � c�mara.
		std::tuple<int, int, int, int> GetViewport() const {
			return std::make_tuple(viewport_.width, viewport_.height, viewport_.x, viewport_.y);
		}

	private:
		// ------------------------------------------------------------
		// Dados-membro privados
		// ------------------------------------------------------------

		// Cor de fundo da c�mara
		glm::vec4 background_color_ = glm::vec4(0.0f);
		// Matriz de visualiza��o da c�mara (matriz View)
		Transform view_;
		// Matriz de proje��o da c�mara (matriz Projection)
		Transform projection_;

		// Tipo de c�mara (perspectiva ou ortogr�fica)
		CameraType camera_type_ = CameraType::kNone;	// Tipo de c�mara (inicialmente definido como 'kNone', ou seja, nenhum tipo de c�mara definido)
		// Propriedades da c�mara
		float prespective_field_of_view_ = 45.0f;	// Campo de vis�o da c�mara (apenas para c�maras perspetivas) em graus
		float orthographic_size_ = 10.0f;			// Tamanho ortogr�fico da c�mara (apenas para c�maras ortogr�ficas) top e bottom. Neste exemplo, o tamanho � 10, ent�o top = 10 e bottom = -10. Left e roght s�o calculados com base na propor��o (aspect ratio) da viewport. Consideramos valores sim�tricos para simplificar a implementa��o.

		// Planos de recorte (clipping planes)
		struct ClippingPlanes {
			float near_plane = 0.1f;	// Plano pr�ximo da c�mara
			float far_plane = 100.0f;	// Plano distante da c�mara
		} clipping_planes_; // Estrutura para armazenar os planos de recorte	

		// Viewport (dimens�o e posi��o)
		struct Viewport {
			int width = kWindowDefaultWidth;	// Largura da viewport (por defeito, a largura da janela do jogo)
			int height = kWindowDefaultHeight;	// Altura da viewport (por defeito, a altura da janela do jogo)
			int x = 0;	// Posi��o (offset em) X da viewport (por defeito, 0)
			int y = 0;	// Posi��o (offset em) Y da viewport (por defeito, 0)
		} viewport_; // Estrutura para armazenar as dimens�es e posi��o da viewport

		// M�scara de culling (layers que a c�mara deve renderizar)
		std::vector<Layer> culling_mask_{ "Default" }; // Por defeito renderiza apenas a layer "Default"
	};
}