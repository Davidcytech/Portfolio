#include <iostream>
#include <array>
#include <string>

#include "Game.h"
#include "Camera.h"
#include "Light.h"
#include "Object.h"
#include "Shader.h"
#include "Renderer.h" // Inclui a classe 'Renderer', que define o renderizador a associar a cada objeto do jogo

// ------------------------------------------------------------
// � aqui que se incluem as suas classes de comportamento personalizados
// ------------------------------------------------------------
#include "Oscilator.h" // Inclui a classe 'Oscilator', que define o comportamento do objeto oscilador

// chamamos qualquer componente da l�gica do c�digo com uma nomenclatura mais curta
namespace gep3d = game_engine_p3d;

int main() {
	// Defini��es regionais (locale) para evitar problemas com n�meros decimais em ficheiros de texto
	try {
#ifdef __linux__
		std::locale::global(std::locale("pt_PT"));
#else
		std::locale::global(std::locale("pt-PT"));
#endif
	}
	catch (const std::exception& e) {
		std::cerr << "Erro ao definir locale: " << e.what() << std::endl;
	}

	// --------------------------------------------------
	// Cria uma inst�ncia do jogo (Aqui est�o as dimens�es da janela)
	// --------------------------------------------------
	gep3d::Game game(1500, 1000);

	// --------------------------------------------------
	// Prepara��o da(s) c�mara(s)
	// --------------------------------------------------
	gep3d::Camera camera;
	camera.set_background_color(glm::vec4(0.1f, 0.1f, 0.1f, 1.0f)); //Cor do background da c�mara
	camera.LookAt(glm::vec3(20.0f, 10.0f, 40.0f), glm::vec3(0.0f, 0.0f, .0f), glm::vec3(0.0f, 1.0f, 0.0f)); //Matriz View
	camera.Prespective(45.0f, static_cast<float>(game.width()) / game.height(), 0.1f, 100.0f); //Matriz Projection
	camera.Viewport(game.width(), game.height(), 0, 0); //isto define a �rea real da janela esticando o programa para ocupar a dimens�o completa da janela

	std::array<std::string, 3> layers = { "Default", "Environment", "UI" };
	for (const auto& layer : layers) {
		camera.AddLayerToCullingMask(layer);
	}

	game.AddCamera(&camera); //Ap�s as prepara��es adiciona a c�mara � cena

	// --------------------------------------------------
	// Prepara��o da(s) luzes(es)
	// --------------------------------------------------
	gep3d::Light* ambient_light = new gep3d::Light(glm::vec3(0.1f, 0.1f, 0.1f)); //Luz Ambiente (Os n�meros representam os valores RGB)
	gep3d::Light* directional_light = new gep3d::Light(
		glm::vec3(0.0f, 0.0f, -1.0f),
		glm::vec3(1.0f, 1.0f, 1.0f),
		glm::vec3(1.0f, 1.0f, 1.0f),
		glm::vec3(1.0f, 1.0f, 1.0f)
	);
	gep3d::Light* point_light = new gep3d::Light(
		glm::vec3(0.0f, 0.0f, -1.0f),
		glm::vec3(1.0f, 1.0f, 1.0f),
		glm::vec3(1.0f, 1.0f, 1.0f),
		glm::vec3(1.0f, 1.0f, 1.0f),
		1.0f,
		0.09f,
		0.032f
	);
	gep3d::Light* spot_light = new gep3d::Light(
		glm::vec3(0.0f, 8.0f, 0.0f),    // 1. POSI��O
		glm::vec3(0.0f, -1.0f, 0.0f),   // 2. DIRE��O
		glm::vec3(0.0f, 0.0f, 0.0f),    // 3. Cor Ambiente
		glm::vec3(1.0f, 1.0f, 1.0f),    // 4. Cor Difusa
		glm::vec3(1.0f, 1.0f, 1.0f),    // 5. Cor Especular
		1.0f,                           // 6. Atenua��o Constante
		0.05f,                          // 7. ATENUA��O LINEAR - luz diminui com a dist�ncia de forma proporcional
		0.012f,                         // 8. ATENUA��O QUADR�TICA - luz diminui com a dist�ncia de forma r�pida
		35.0f,                          // 9. SPOT CUTOFF - �ngulo do cone
		5.0f                            // 10. SPOT EXPONENT - diferen�a entre centro e bordas
	);
	//A marcar que as luzes s� iluminam objetos que estiverem na layer default
	ambient_light->AddLayerToLightLayers("Default");
	directional_light->AddLayerToLightLayers("Default");
	point_light->AddLayerToLightLayers("Default");
	spot_light->AddLayerToLightLayers("Default");
	//Adiciona as luzes ao jogo
	game.AddLight(ambient_light);
	game.AddLight(directional_light);
	game.AddLight(point_light);
	game.AddLight(spot_light);

	// --------------------------------------------------
	// Prepara��o do(s) programa(s) shader
	// --------------------------------------------------
	// Mantemos APENAS o shader original das bolas que funciona de certeza
	std::vector<ShaderSource> sources = {
		{GL_VERTEX_SHADER, "light.vert"},
		{GL_FRAGMENT_SHADER, "light.frag"}
	};
	Shader* shader = new Shader(sources, "DefaultShader");

	// --------------------------------------------------
	// Prepara��o do(s) renderizador(es)
	// --------------------------------------------------
	Renderer* renderer1 = new Renderer(shader, "Ball1.obj");
	Renderer* renderer2 = new Renderer(shader, "Ball2.obj");
	Renderer* renderer3 = new Renderer(shader, "Ball3.obj");
	Renderer* renderer4 = new Renderer(shader, "Ball4.obj");
	Renderer* renderer5 = new Renderer(shader, "Ball5.obj");
	Renderer* renderer6 = new Renderer(shader, "Ball6.obj");
	Renderer* renderer7 = new Renderer(shader, "Ball7.obj");	
	Renderer* renderer8 = new Renderer(shader, "Ball8.obj");
	Renderer* renderer9 = new Renderer(shader, "Ball9.obj");
	Renderer* renderer10 = new Renderer(shader, "Ball10.obj");
	Renderer* renderer11 = new Renderer(shader, "Ball11.obj");
	Renderer* renderer12 = new Renderer(shader, "Ball12.obj");
	Renderer* renderer13 = new Renderer(shader, "Ball13.obj");
	Renderer* renderer14 = new Renderer(shader, "Ball14.obj");
	Renderer* renderer15 = new Renderer(shader, "Ball15.obj");

	// NOVO 
	gep3d::Renderer* rendererBaseMesa = new gep3d::Renderer(shader, "base_mesa.obj");

	// --------------------------------------------------
	// Prepara��o do(s) comportamento(s) do(s) objeto(s)
	// --------------------------------------------------
	Oscilator* oscilator = new Oscilator();

	// --------------------------------------------------
	// Prepara��o do(s) objeto(s) do jogo
	// --------------------------------------------------
	gep3d::Object* Ball1 = new gep3d::Object("Ball1", "Default", oscilator, renderer1, 0.0f, -2.0f, 0.0f); //NOVO adicionei propriedade oscilator
	gep3d::Object* Ball2 = new gep3d::Object("Ball2", "", nullptr, renderer2, 3.0f, -2.0f, 4.0f);
	gep3d::Object* Ball3 = new gep3d::Object("Ball3", "", nullptr, renderer3, -4.0f, -2.0f, -3.0f);
	gep3d::Object* Ball4 = new gep3d::Object("Ball4", "", nullptr, renderer4, 6.0f, -2.0f, -5.0f);
	gep3d::Object* Ball5 = new gep3d::Object("Ball5", "", nullptr, renderer5, 8.0f, -2.0f, -3.0f);
	gep3d::Object* Ball6 = new gep3d::Object("Ball6", "", nullptr, renderer6, -10.0f, -2.0f, 5.0f);
	gep3d::Object* Ball7 = new gep3d::Object("Ball7", "", nullptr, renderer7, 12.0f, -2.0f, -1.0f);
	gep3d::Object* Ball8 = new gep3d::Object("Ball8", "", nullptr, renderer8, -2.0f, -2.0f, 6.0f);
	gep3d::Object* Ball9 = new gep3d::Object("Ball9", "", nullptr, renderer9, 5.0f, -2.0f, 5.0f);
	gep3d::Object* Ball10 = new gep3d::Object("Ball10", "", nullptr, renderer10, -7.0f, -2.0f, -4.0f);
	gep3d::Object* Ball11 = new gep3d::Object("Ball11", "", nullptr, renderer11, 14.0f, -2.0f, 0.0f);
	gep3d::Object* Ball12 = new gep3d::Object("Ball12", "", nullptr, renderer12, -12.0f, -2.0f, -2.0f);
	gep3d::Object* Ball13 = new gep3d::Object("Ball13", "", nullptr, renderer13, 2.0f, -2.0f, -6.0f);
	gep3d::Object* Ball14 = new gep3d::Object("Ball14", "", nullptr, renderer14, 10.0f, -2.0f, 4.0f);
	gep3d::Object* Ball15 = new gep3d::Object("Ball15", "", nullptr, renderer15, -5.0f, -2.0f, 1.0f);

	// NOVO
	gep3d::Object* MesaDefinitiva = new gep3d::Object("Mesa", "Default", nullptr, rendererBaseMesa,
		0.0f, -3.8f, 0.0f,        // Posi��o Y ajustada
		0.0f, 0.0f, 0.0f,         // Rota��o
		1.0f, 10.0f, 1.0f         // Escala Y a 10 para dar corpo
	);	


	// --------------------------------------------------
	// LOGS
	// --------------------------------------------------
	LOG("Object created with ID: " << Ball1->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball2->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball3->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball4->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball5->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball6->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball7->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball8->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball9->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball10->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball11->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball12->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball13->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball14->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << Ball15->id() << " at position: (0, -4, 0).");
	LOG("Object created with ID: " << MesaDefinitiva->id() << " at position: (0, -3, 0).");


	// --------------------------------------------------
	// Adiciona o(s) objeto(s) ao jogo
	// --------------------------------------------------
	game.AddObject(Ball1);
	game.AddObject(Ball2);
	game.AddObject(Ball3);
	game.AddObject(Ball4);
	game.AddObject(Ball5);
	game.AddObject(Ball6);
	game.AddObject(Ball7);
	game.AddObject(Ball8);
	game.AddObject(Ball9);
	game.AddObject(Ball10);
	game.AddObject(Ball11);
	game.AddObject(Ball12);
	game.AddObject(Ball13);
	game.AddObject(Ball14);
	game.AddObject(Ball15);
	game.AddObject(MesaDefinitiva); //NOVO

	// --------------------------------------------------
	// Inicia o loop do jogo
	// --------------------------------------------------
	game.Run();

	// --------------------------------------------------
	// Liberta a mem�ria alocada para os recursos do jogo
	// --------------------------------------------------
	delete shader;
	delete oscilator;

	delete renderer1;
	delete renderer2;
	delete renderer3;
	delete renderer4;
	delete renderer5;
	delete renderer6;
	delete renderer7;
	delete renderer8;
	delete renderer9;
	delete renderer10;
	delete renderer11;
	delete renderer12;
	delete renderer13;
	delete renderer14;
	delete renderer15;
	delete rendererBaseMesa; //NOVO

	delete Ball1;
	delete Ball2;
	delete Ball3;
	delete Ball4;
	delete Ball5;
	delete Ball6;
	delete Ball7;
	delete Ball8;
	delete Ball9;
	delete Ball10;
	delete Ball11;
	delete Ball12;
	delete Ball13;
	delete Ball14;
	delete Ball15;
	delete MesaDefinitiva; //NOVO

	LOG("Exit!");

	return 0;
}